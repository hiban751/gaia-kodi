# -*- coding: utf-8 -*-
"""Módulos auxiliares del addon Gaia."""
