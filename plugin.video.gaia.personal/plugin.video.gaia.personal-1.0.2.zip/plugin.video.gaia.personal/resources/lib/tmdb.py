# -*- coding: utf-8 -*-
"""Cliente ligero de TMDB v3 para Gaia.

Solamente usa urllib/json de la biblioteca estándar. Las respuestas se
guardan en la caché SQLite del addon: búsquedas con el TTL configurado y
detalles/temporadas con un TTL estable de 7 días.
"""

import json
import re
import urllib.error
import urllib.parse
import urllib.request

import xbmc

from resources.lib.cache import TTL_ESTABLE

API_BASE = 'https://api.themoviedb.org/3'
IMG_POSTER = 'https://image.tmdb.org/t/p/w500'
IMG_FANART = 'https://image.tmdb.org/t/p/w1280'
IMG_STILL = 'https://image.tmdb.org/t/p/w500'
IDIOMA = 'es-ES'
RESPALDO = 'en-US'
AGENTE = 'gaia_kodi'


class TMDBError(Exception):
    """Error de red, de respuesta o de configuración de TMDB."""


def extraer_anio(texto):
    """Devuelve el primer año (1900-2099) presente en el texto."""
    encontrado = re.search(r'(?<!\d)(?:19|20)\d{2}(?!\d)', str(texto or ''))
    return int(encontrado.group(0)) if encontrado else None


def url_imagen(ruta, tipo='poster'):
    """Convierte una ruta de TMDB en URL absoluta del tamaño solicitado."""
    ruta = str(ruta or '').strip()
    if not ruta:
        return ''
    if ruta.startswith(('http://', 'https://')):
        return ruta
    bases = {'poster': IMG_POSTER, 'fanart': IMG_FANART, 'still': IMG_STILL}
    base = bases.get(tipo, IMG_POSTER)
    return base + (ruta if ruta.startswith('/') else '/' + ruta)


def _entero(valor, defecto=0):
    try:
        return int(valor)
    except (TypeError, ValueError):
        return defecto


def _flotante(valor):
    try:
        return float(valor)
    except (TypeError, ValueError):
        return 0.0


def clasificar(meta, tipo):
    """Aplica las reglas de género/país para elegir la categoría de Gaia."""
    meta = meta or {}
    generos = set()
    for valor in meta.get('genero_ids') or []:
        try:
            generos.add(int(valor))
        except (TypeError, ValueError):
            pass

    paises = [str(pais or '').upper() for pais in meta.get('pais_origen') or []]
    if 99 in generos:
        return 'documentales'
    if 16 in generos and any(pais.startswith('JP') for pais in paises):
        return 'anime'
    return 'series' if tipo == 'tv' else 'peliculas'


class TMDBClient(object):
    """Consulta TMDB v3 y devuelve metadatos normalizados para Kodi."""

    def __init__(self, apikey, cache=None, idioma=IDIOMA):
        self.apikey = str(apikey or '').strip()
        self.cache = cache
        self.idioma = idioma or IDIOMA

    # ------------------------------------------------------------------ red

    def _peticion(self, ruta, parametros=None, ttl_minutos=None):
        """Llama a un endpoint y devuelve el JSON ya cacheado cuando procede."""
        if not self.apikey:
            raise TMDBError('Falta la API Key de TMDB. Configúrala en los ajustes de Gaia.')

        params = dict(parametros or {})
        params.setdefault('language', self.idioma)
        params['api_key'] = self.apikey
        consulta = urllib.parse.urlencode(params, doseq=True)
        clave_cache = '%s?%s' % (
            ruta, urllib.parse.urlencode(sorted(params.items()), doseq=True))

        if self.cache:
            guardado = self.cache.get('tmdb', clave_cache, ttl_minutos)
            if guardado is not None:
                xbmc.log('[Gaia] TMDB %s desde caché SQLite' % ruta, xbmc.LOGDEBUG)
                return guardado

        xbmc.log('[Gaia] TMDB %s en vivo' % ruta, xbmc.LOGDEBUG)
        url = '%s/%s?%s' % (API_BASE, ruta.lstrip('/'), consulta)
        cabeceras = {'User-Agent': AGENTE, 'Accept': 'application/json'}
        peticion = urllib.request.Request(url, headers=cabeceras, method='GET')

        try:
            with urllib.request.urlopen(peticion, timeout=20) as respuesta:
                contenido = respuesta.read().decode('utf-8')
            datos = json.loads(contenido)
        except urllib.error.HTTPError as exc:
            mensaje = self._mensaje_error(exc)
            xbmc.log('[Gaia] TMDB HTTP %s en %s: %s' % (exc.code, ruta, mensaje),
                     xbmc.LOGWARNING)
            raise TMDBError(mensaje)
        except (urllib.error.URLError, OSError, ValueError, UnicodeError) as exc:
            mensaje = 'No se pudo consultar TMDB. Revisa la conexión e inténtalo de nuevo.'
            xbmc.log('[Gaia] TMDB en %s: %s' % (ruta, exc), xbmc.LOGWARNING)
            raise TMDBError(mensaje)

        if not isinstance(datos, dict):
            raise TMDBError('TMDB devolvió una respuesta inesperada.')
        if datos.get('success') is False or (
                'status_code' in datos and 'results' not in datos and 'id' not in datos):
            mensaje = str(datos.get('status_message') or datos.get('status_code') or
                          'TMDB devolvió un error.')
            xbmc.log('[Gaia] TMDB en %s: %s' % (ruta, mensaje), xbmc.LOGWARNING)
            raise TMDBError(mensaje)

        if self.cache:
            self.cache.set('tmdb', clave_cache, datos, ttl_minutos)
        return datos

    @staticmethod
    def _mensaje_error(exc):
        """Extrae status_message del cuerpo de un HTTPError cuando existe."""
        try:
            datos = json.loads(exc.read().decode('utf-8'))
            if isinstance(datos, dict) and datos.get('status_message'):
                return str(datos['status_message'])
        except (ValueError, UnicodeError, OSError, AttributeError):
            pass
        return 'TMDB devolvió el error HTTP %s.' % exc.code

    # ------------------------------------------------------------- búsqueda

    def buscar(self, tipo, titulo, anio=None):
        """Busca una película/serie y devuelve su metadato normalizado."""
        if tipo not in ('movie', 'tv'):
            return None
        titulo = str(titulo or '').strip()
        if not titulo or not self.apikey:
            return None

        ruta = 'search/movie' if tipo == 'movie' else 'search/tv'
        parametros = {'query': titulo, 'include_adult': 'false', 'page': 1}
        if anio:
            clave_anio = 'year' if tipo == 'movie' else 'first_air_date_year'
            parametros[clave_anio] = int(anio)

        datos = self._peticion(ruta, parametros)
        resultados = [item for item in (datos.get('results') or [])
                      if isinstance(item, dict) and item.get('id')]
        if not resultados:
            return None

        elegido = None
        if anio:
            for resultado in resultados:
                fecha = resultado.get('release_date') or resultado.get('first_air_date') or ''
                if extraer_anio(fecha) == int(anio):
                    elegido = resultado
                    break
        elegido = elegido or resultados[0]
        return self.detalle(tipo, elegido['id'], elegido)

    def detalle(self, tipo, identificador, base=None):
        """Obtiene el detalle completo; usa en-US si falta sinopsis en español."""
        if not identificador or tipo not in ('movie', 'tv'):
            return None

        ruta = '%s/%s' % (tipo, identificador)
        datos = dict(self._peticion(ruta, ttl_minutos=TTL_ESTABLE))
        if not datos.get('overview'):
            alterno = self._peticion(ruta, {'language': RESPALDO}, ttl_minutos=TTL_ESTABLE)
            if alterno.get('overview'):
                datos['overview'] = alterno['overview']

        for clave in ('poster_path', 'backdrop_path', 'vote_average', 'vote_count'):
            if not datos.get(clave) and isinstance(base, dict) and base.get(clave):
                datos[clave] = base[clave]

        return self._normalizar(datos, tipo)

    # ----------------------------------------------------------- temporadas

    def temporada(self, serie_id, numero):
        """Devuelve la temporada y sus episodios indexados por número."""
        numero = _entero(numero, 1) or 1
        resultado = {'numero': numero, 'nombre': 'Temporada %d' % numero,
                     'sinopsis': '', 'poster': '', 'fanart': '', 'episodios': {}}
        if not serie_id:
            return resultado

        ruta = 'tv/%s/season/%s' % (serie_id, numero)
        datos = dict(self._peticion(ruta, ttl_minutos=TTL_ESTABLE))
        episodios = [item for item in (datos.get('episodes') or [])
                     if isinstance(item, dict)]
        if episodios and not any(item.get('overview') for item in episodios):
            alterno = self._peticion(ruta, {'language': RESPALDO},
                                     ttl_minutos=TTL_ESTABLE)
            por_numero = {_entero(item.get('episode_number')): item
                          for item in (alterno.get('episodes') or [])
                          if isinstance(item, dict)}
            completados = []
            for item in episodios:
                if not item.get('overview'):
                    otro = por_numero.get(_entero(item.get('episode_number'))) or {}
                    if otro.get('overview'):
                        item = dict(item)
                        item['overview'] = otro['overview']
                completados.append(item)
            episodios = completados

        for item in episodios:
            numero_episodio = _entero(item.get('episode_number'))
            if not numero_episodio:
                continue
            resultado['episodios'][numero_episodio] = {
                'numero': numero_episodio,
                'titulo': item.get('name') or 'Episodio %d' % numero_episodio,
                'sinopsis': item.get('overview') or '',
                'still': url_imagen(item.get('still_path'), 'still'),
                'puntuacion': _flotante(item.get('vote_average')),
                'anio': extraer_anio(item.get('air_date') or ''),
                'estreno': item.get('air_date') or '',
            }

        resultado.update({
            'numero': _entero(datos.get('season_number'), numero),
            'nombre': datos.get('name') or resultado['nombre'],
            'sinopsis': datos.get('overview') or '',
            'poster': url_imagen(datos.get('poster_path'), 'poster'),
        })
        return resultado

    clasificar = staticmethod(clasificar)

    # --------------------------------------------------------- normalizar

    @staticmethod
    def _normalizar(datos, tipo):
        """Convierte la respuesta de TMDB al diccionario usado por Gaia."""
        generos = datos.get('genres') or []
        if isinstance(generos, dict):
            generos = [generos]
        nombres = [str(item.get('name')) for item in generos
                   if isinstance(item, dict) and item.get('name')]
        identificadores = [item.get('id') for item in generos
                           if isinstance(item, dict) and item.get('id') is not None]
        if not identificadores:
            identificadores = [_entero(item) for item in (datos.get('genre_ids') or [])
                               if _entero(item)]

        paises = datos.get('origin_country') or []
        if isinstance(paises, str):
            paises = [paises]
        if not paises:
            produccion = datos.get('production_countries') or []
            paises = [item.get('iso_3166_1') for item in produccion
                      if isinstance(item, dict) and item.get('iso_3166_1')]

        duracion = _entero(datos.get('runtime'))
        if not duracion:
            tiempos = datos.get('episode_run_time') or []
            if tiempos:
                duracion = _entero(tiempos[0])

        fecha = datos.get('release_date') or datos.get('first_air_date') or ''
        return {
            'id': datos.get('id'),
            'imdb': datos.get('imdb_id') or '',
            'tipo': tipo,
            'titulo': datos.get('title') or datos.get('name') or '',
            'sinopsis': datos.get('overview') or '',
            'anio': extraer_anio(fecha),
            'estreno': fecha,
            'puntuacion': _flotante(datos.get('vote_average')),
            'votos': _entero(datos.get('vote_count')),
            'generos': nombres,
            'genero_ids': identificadores,
            'pais_origen': [str(pais) for pais in paises],
            'duracion': duracion,
            'poster': url_imagen(datos.get('poster_path'), 'poster'),
            'fanart': url_imagen(datos.get('backdrop_path'), 'fanart'),
            'poster_path': datos.get('poster_path') or '',
            'backdrop_path': datos.get('backdrop_path') or '',
        }
