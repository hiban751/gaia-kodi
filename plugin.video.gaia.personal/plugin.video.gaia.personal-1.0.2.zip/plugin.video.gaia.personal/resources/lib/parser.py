# -*- coding: utf-8 -*-
"""Limpieza y clasificación de nombres de torrents para Gaia.

Toda la lógica trabaja sobre cadenas y expresiones regulares de la
biblioteca estándar, sin consultar servicios externos.
"""

import re
import unicodedata

# Etiquetas típicas de releases que no aportan al título visible.
RESOLUCION = (r'\b(?:2160p|1080p|720p|576p|480p|4k|uhd|hdr10?|10bit|8bit|dv|remux|'
              r'web[- ._]?dl|blu[- ._]?ray)\b')
CODEC = (r'\b(?:x264|x265|hevc|av1|avc|h[ ._-]?264|h[ ._-]?265|aac|ac3|eac3|'
         r'ddp?5[ ._-]?1|flac)\b')
IDIOMA = r'\b(?:esp|español|spanish|castellano|dual|sub\s*esp|subes|vose|vosi|latino)\b'
RELEASE = r'\b(?:fansub|fandub|anime|subtitles?|sub|horriblesubs|subsplease|erai[- ]?raws)\b'

DOCUMENTAL = (r'\b(?:documental(?:es)?|documentary|documentaries|docu|'
              r'national geographic|nat\s*geo|bbc|discovery channel)\b')
ANIME = (r'\b(?:anime|fansub|fandub|horriblesubs|subsplease|erai[- ]?raws|nyaa|'
         r'sub(?:titles?)?[ ._-]*(?:esp|español|spanish))\b')

# Etiquetas usadas para distinguir versiones de una misma película.
RESOLUCIONES = (
    (r'\b(?:4k|2160p|uhd)\b', '4K'),
    (r'\b1080p\b', '1080p'),
    (r'\b720p\b', '720p'),
    (r'\b576p\b', '576p'),
    (r'\b480p\b', '480p'),
)
TECNICAS = (
    (r'\b(?:hdr10\+?|hdr)(?![a-z0-9])', 'HDR'),
    (r'\b(?:dolby\s*vision|dv)(?![a-z0-9])', 'DV'),
    (r'\bremux\b', 'REMUX'),
    (r'\bweb[- ._]?dl\b', 'WEB-DL'),
    (r'\bblu[- ._]?ray\b', 'Bluray'),
    (r'\b10[- ]?bit\b', '10bit'),
)
ANIO = r'(?<!\d)(?:19|20)\d{2}(?!\d)'


def limpiar_nombre(nombre):
    """Quita extensión, corchetes, resolución, codec e idioma de un nombre."""
    texto = str(nombre or '')
    texto = re.sub(r'\.(?:mkv|mp4|avi|mov|m4v|ts)$', '', texto, flags=re.I)
    texto = re.sub(r'\[[^\]]*\]|\([^)]*\)', ' ', texto)
    texto = re.sub(RESOLUCION, ' ', texto, flags=re.I)
    texto = re.sub(CODEC, ' ', texto, flags=re.I)
    texto = re.sub(IDIOMA, ' ', texto, flags=re.I)
    texto = re.sub(RELEASE, ' ', texto, flags=re.I)
    texto = re.sub(r'[._]+', ' ', texto)
    texto = re.sub(r'\s+', ' ', texto).strip(' -')

    # Nombres escritos todo en mayúsculas se convierten en título legible.
    if texto and re.search(r'[A-Z]', texto) and not re.search(r'[a-z]', texto):
        texto = texto.title()
    return texto


def extraer_anio(nombre):
    """Devuelve el año presente en el nombre, o None."""
    encontrado = re.search(ANIO, str(nombre or ''))
    return int(encontrado.group(0)) if encontrado else None


def extraer_calidad(nombre):
    """Resume la resolución y las etiquetas técnicas de un lanzamiento."""
    texto = str(nombre or '')
    etiquetas = []
    for patron, etiqueta in RESOLUCIONES:
        if re.search(patron, texto, flags=re.I):
            etiquetas.append(etiqueta)
            break
    for patron, etiqueta in TECNICAS:
        if re.search(patron, texto, flags=re.I) and etiqueta not in etiquetas:
            etiquetas.append(etiqueta)
    if etiquetas:
        return ' '.join(etiquetas)
    return limpiar_nombre(texto) or texto.strip()


def normalizar_texto(texto):
    """Convierte un título a minúsculas sin acentos ni signos."""
    ascii_texto = unicodedata.normalize('NFKD', str(texto or ''))
    ascii_texto = ascii_texto.encode('ascii', 'ignore').decode('ascii')
    return re.sub(r'[^a-z0-9]+', ' ', ascii_texto.lower()).strip()


def clave_pelicula(titulo='', anio=None, tmdb_id=None, nombre=''):
    """Clave estable para agrupar versiones de la misma película."""
    if tmdb_id not in (None, ''):
        return 'tmdb:%s' % str(tmdb_id).strip()

    try:
        anio = int(anio) if anio not in (None, '') else None
    except (TypeError, ValueError):
        anio = None

    texto = limpiar_nombre(titulo) or limpiar_nombre(nombre)
    normalizado = normalizar_texto(texto)
    if not normalizado:
        normalizado = normalizar_texto(nombre) or 'sin-titulo'

    if not anio:
        anio = extraer_anio('%s %s' % (titulo or '', nombre or ''))
    return '%s:%s' % (normalizado, anio) if anio else normalizado


def detectar_episodio(nombre):
    """Detecta temporada/episodio.

    Devuelve (temporada, episodio, es_anime) o None cuando no hay patrón.
    El episodio puede ser None en carpetas de tipo 'Temporada 2'.
    """
    texto = str(nombre or '')
    texto = re.sub(r'\.(?:mkv|mp4|avi|mov|m4v|ts)$', '', texto, flags=re.I)

    patrones_con_temporada = (
        r'\bS(\d{1,2})\s*[- ._]*E(\d{1,4})\b',   # S01E01
        r'\bT(\d{1,2})\s*[- ._]*E(\d{1,4})\b',   # T01E01
        r'(?<!\d)(\d{1,2})[xX](\d{1,4})(?!\d)',  # 1x01
    )
    for patron in patrones_con_temporada:
        encontrado = re.search(patron, texto, flags=re.I)
        if encontrado:
            return int(encontrado.group(1)), int(encontrado.group(2)), False

    # Las etiquetas entre corchetes pueden contener el episodio.
    for etiqueta in re.findall(r'\[([^\]]*)\]|\(([^)]*)\)', texto):
        patron = next((parte for parte in etiqueta if parte), '')
        episodio_etiqueta = detectar_episodio(patron)
        if episodio_etiqueta and episodio_etiqueta[1] is not None:
            return episodio_etiqueta

    texto = limpiar_nombre(texto)

    # Cap.101 se interpreta como 1x01; Cap.215 se reparte como 2x15.
    encontrado = re.search(r'\bcaps?(?:itulo)?\.?\s*[- ._]*(\d{1,4})\b', texto, flags=re.I)
    if encontrado:
        cifras = encontrado.group(1)
        if len(cifras) == 3 and cifras[0] != '0':
            return int(cifras[0]), int(cifras[1:]), False
        return 1, int(cifras), False

    encontrado = re.search(r'\b(?:episodio|ep)\.?\s*[- ._]*(\d{1,4})\b', texto, flags=re.I)
    if encontrado:
        return 1, int(encontrado.group(1)), False

    encontrado = re.search(r'\b(?:temporada|temp|season)\.?\s*(\d{1,2})\b', texto, flags=re.I)
    if encontrado:
        return int(encontrado.group(1)), None, False

    # E01 suelto: episodio sin temporada, típico de anime.
    encontrado = re.search(r'(?<![a-z0-9])E[- ._]?(\d{1,4})(?![a-z0-9])', texto, flags=re.I)
    if encontrado:
        return 1, int(encontrado.group(1)), True

    # Número suelto al final (01, 1050...). Se descartan años como 1999.
    numeros = [int(numero) for numero in re.findall(r'(?<!\d)(\d{1,4})(?!\d)', texto)]
    utiles = [numero for numero in numeros if not 1900 <= numero <= 2099]
    if utiles:
        return 1, utiles[-1], True
    return None


def quitar_marcadores_episodio(texto):
    """Elimina etiquetas técnicas y marcadores de episodio de un nombre."""
    texto = str(texto or '')
    texto = re.sub(r'\.(?:mkv|mp4|avi|mov|m4v|ts)$', '', texto, flags=re.I)
    texto = re.sub(RESOLUCION, ' ', texto, flags=re.I)
    texto = re.sub(CODEC, ' ', texto, flags=re.I)
    texto = re.sub(IDIOMA, ' ', texto, flags=re.I)
    texto = re.sub(RELEASE, ' ', texto, flags=re.I)
    limpiezas = (
        r'\[[^\]]*(?:caps?(?:itulo)?|episodio|ep|e)\.?\s*[- ._]*\d{1,4}[^\]]*\]',
        r'\([^)]*(?:caps?(?:itulo)?|episodio|ep|e)\.?\s*[- ._]*\d{1,4}[^)]*\)',
        r'\bS\d{1,2}\s*[- ._]*E\d{1,4}\b',
        r'\bT\d{1,2}\s*[- ._]*E\d{1,4}\b',
        r'(?<!\d)\d{1,2}[xX]\d{1,4}(?!\d)',
        r'\b(?:caps?(?:itulo)?|episodio|ep|e)\.?\s*[- ._]*\d{1,4}\b',
        r'\b(?:temporada|temp|season)\.?\s*\d{1,2}\b',
        r'(?<!\d)\d{1,4}(?!\d)\s*$',
    )
    for patron in limpiezas:
        texto = re.sub(patron, ' ', texto, flags=re.I)
    return texto


def titulo_serie(nombre):
    """Elimina marcadores de temporada/episodio para agrupar por título."""
    texto = limpiar_nombre(quitar_marcadores_episodio(nombre))
    texto = re.sub(r'\s+', ' ', texto).strip(' -[]()')
    return texto or limpiar_nombre(nombre) or limpiar_nombre(str(nombre or ''))


def parsear_video(filename, nombre_origen=''):
    """Clasifica un archivo y devuelve sus metadatos básicos."""
    archivo = str(filename or '').strip()
    origen = str(nombre_origen or '').strip()

    episodio = detectar_episodio(archivo) or detectar_episodio(origen)
    if episodio:
        temporada, numero, anime_por_numero = episodio
    else:
        temporada, numero, anime_por_numero = None, None, False

    # Si el magnet no tiene número de episodio, suele ser el mejor título.
    base = origen if origen and not detectar_episodio(origen) else archivo
    titulo = titulo_serie(base)

    contexto = '%s %s' % (archivo, origen)
    texto = contexto.lower()
    if re.search(DOCUMENTAL, texto):
        categoria = 'documentales'
    elif re.search(ANIME, texto):
        categoria = 'anime'
    elif numero is not None and anime_por_numero:
        categoria = 'anime'
    elif numero is not None or temporada is not None:
        categoria = 'series'
    else:
        categoria = 'peliculas'

    return {
        'title': titulo,
        'category': categoria,
        'season': temporada,
        'episode': numero,
        'filename': archivo,
        'quality': extraer_calidad(contexto),
        'movie_key': clave_pelicula(titulo=titulo, nombre=contexto),
    }


def clave_agrupacion(titulo):
    """Normaliza un título para usarlo como clave de agrupación de series.

    Ignora mayúsculas, acentos, puntuación, etiquetas técnicas y marcadores
    de episodio para que variantes del mismo título acaben en la misma clave.
    """
    texto = quitar_marcadores_episodio(titulo)
    texto = re.sub(r'\[[^\]]*\]|\([^)]*\)|\{[^}]*\}', ' ', texto)
    normalizado = normalizar_texto(texto)
    return normalizado or 'sin-titulo'
