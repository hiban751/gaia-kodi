# -*- coding: utf-8 -*-
"""Cliente mínimo de la API actual de AllDebrid para Gaia.

Usa los endpoints vigentes: /v4.1/magnet/status, /v4/magnet/files,
/v4/user/links y /v4/link/unlock. Solamente usa la biblioteca estándar de
Python 3 que trae Kodi (urllib, json, os y time), sin dependencias extra.
"""

import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcgui

API_BASE = 'https://api.alldebrid.com'
AGENT = 'gaia_kodi'
AGENTE_PIN = 'GaiaKodi/1.0'
ESTADO_MAGNETS = 'v4.1/magnet/status'
ARCHIVOS_MAGNETS = 'v4/magnet/files'
ENLACES_GUARDADOS = 'v4/user/links'
DESBLOQUEAR = 'v4/link/unlock'
PIN_GET = 'v4.1/pin/get'
PIN_CHECK = 'v4/pin/check'
URL_ACTIVACION_PIN = 'https://alldebrid.es/pin/'
INTERVALO_PIN = 5
DURACION_PIN = 600
VIDEO_EXTENSIONS = ('.mkv', '.mp4', '.avi', '.mov', '.m4v', '.ts')
READY_STATUSES = ('ready', 'complete', 'completed', 'finished')


class AllDebridError(Exception):
    """Error devuelto por la API de AllDebrid o por la red."""


def _lista(datos):
    """Normaliza listas que la API devuelve como objeto indexado por claves."""
    if isinstance(datos, dict):
        claves = [str(clave).lower() for clave in datos]
        if any(clave in claves for clave in ('id', 'status', 'statuscode', 'filename')):
            return [datos]
        return [valor for valor in datos.values() if isinstance(valor, dict)]
    if isinstance(datos, list):
        return datos
    return []


class AllDebridPinError(AllDebridError):
    """Error controlado del flujo de vinculación por PIN."""

    def __init__(self, mensaje, esperada=False):
        super(AllDebridPinError, self).__init__(mensaje)
        self.esperada = esperada


def _avisar(mensaje):
    """Muestra un aviso visible en la interfaz de Kodi."""
    xbmcgui.Dialog().notification('Gaia - AllDebrid', mensaje,
                                  xbmcgui.NOTIFICATION_ERROR, 5000)
    xbmc.log('[Gaia] AllDebrid: %s' % mensaje, xbmc.LOGWARNING)


def _entero(valor, defecto=0):
    """Convierte un número devuelto por la API con valor de respaldo."""
    try:
        return int(valor)
    except (TypeError, ValueError):
        return defecto


def _error_pin(respuesta, defecto):
    """Devuelve (mensaje, código) a partir de un error de la API de PIN."""
    error = respuesta.get('error') or {}
    if isinstance(error, dict):
        mensaje = error.get('message') or error.get('code') or ''
        codigo = str(error.get('code') or '')
    elif isinstance(error, str):
        mensaje = error
        codigo = ''
    else:
        mensaje = str(respuesta.get('message') or '')
        codigo = ''
    if not mensaje:
        mensaje = defecto or ('AllDebrid devolvió un error (%s).' % (
            codigo or 'desconocido'))
    return mensaje, codigo


def _peticion_pin(endpoint, metodo='GET', cuerpo=None, timeout=20):
    """Llama a los endpoints públicos de PIN sin apikey y devuelve el JSON."""
    url = '%s/%s' % (API_BASE, endpoint.lstrip('/'))
    cabeceras = {
        'User-Agent': AGENTE_PIN,
        'Accept': 'application/json',
    }
    contenido = None
    if cuerpo is not None:
        contenido = urllib.parse.urlencode(cuerpo, doseq=True).encode('utf-8')
        cabeceras['Content-Type'] = 'application/x-www-form-urlencoded'
    peticion = urllib.request.Request(url, data=contenido, headers=cabeceras,
                                      method=metodo)
    try:
        with urllib.request.urlopen(peticion, timeout=timeout) as respuesta:
            texto = respuesta.read().decode('utf-8', errors='ignore')
        datos = json.loads(texto) if texto.strip() else {}
    except urllib.error.HTTPError as exc:
        try:
            detalle = exc.read().decode('utf-8', errors='ignore').strip()
        except (OSError, ValueError, AttributeError):
            detalle = ''
        raise AllDebridPinError('AllDebrid devolvió HTTP %d al consultar el PIN.%s' % (
            exc.code, (' %s' % detalle) if detalle else ''))
    except (urllib.error.URLError, OSError, TypeError, ValueError, UnicodeError) as exc:
        raise AllDebridPinError(
            'No se pudo conectar con AllDebrid para vincular la cuenta: %s' % exc)
    if not isinstance(datos, dict):
        raise AllDebridPinError(
            'AllDebrid devolvió una respuesta inesperada al vincular la cuenta.')
    return datos


def obtener_pin():
    """Solicita un PIN y su token de comprobación a AllDebrid."""
    respuesta = _peticion_pin(PIN_GET, metodo='GET')
    if respuesta.get('status') != 'success':
        mensaje, _codigo = _error_pin(
            respuesta, 'No se pudo solicitar el PIN de AllDebrid.')
        raise AllDebridPinError(mensaje)
    datos = respuesta.get('data') or {}
    if not isinstance(datos, dict):
        raise AllDebridPinError('AllDebrid no devolvió un PIN válido.')
    pin = str(datos.get('pin') or '').strip()
    check = str(datos.get('check') or '').strip()
    if not pin or not check:
        raise AllDebridPinError('AllDebrid no devolvió un PIN válido.')
    return {
        'pin': pin,
        'check': check,
        'expires_in': max(1, _entero(datos.get('expires_in'), DURACION_PIN)),
    }


def comprobar_pin(check, pin):
    """Comprueba el PIN y devuelve su estado y, si procede, la apikey."""
    respuesta = _peticion_pin(PIN_CHECK, metodo='POST',
                             cuerpo={'check': check, 'pin': pin})
    datos = respuesta.get('data') or {}
    if not isinstance(datos, dict):
        datos = {}
    if respuesta.get('status') == 'error':
        mensaje, codigo = _error_pin(
            respuesta, 'No se pudo comprobar el PIN de AllDebrid.')
        return {'activated': False, 'apikey': '', 'expires_in': 0,
                'error': mensaje, 'codigo': codigo}
    activado = datos.get('activated') in (True, 1, '1', 'true', 'True', 'yes')
    return {
        'activated': activado,
        'apikey': str(datos.get('apikey') or '').strip(),
        'expires_in': max(0, _entero(datos.get('expires_in'), 0)),
        'error': '',
        'codigo': '',
    }


def vincular_pin(guardar_apikey=None):
    """Muestra el PIN, espera su activación y guarda la apikey resultante."""
    try:
        xbmc.executebuiltin('Dialog.Close(all,true)')
    except Exception:
        pass

    sesion = obtener_pin()
    pin = sesion['pin']
    check = sesion['check']
    duracion = max(1, sesion['expires_in'])
    fin = time.time() + duracion
    proximo = 0.0
    mensaje = ('Entra en: %s\n'
               'Introduce el PIN: %s\n'
               'Esperando activación...') % (URL_ACTIVACION_PIN, pin)
    progreso = xbmcgui.DialogProgress()
    creado = False
    try:
        progreso.create('Gaia - AllDebrid', mensaje)
        creado = True
        while time.time() < fin:
            if progreso.iscanceled():
                raise AllDebridPinError(
                    'Vinculación de AllDebrid cancelada.', esperada=True)
            restante = max(0, int(fin - time.time()))
            porcentaje = min(99, int(100 * (1 - restante / float(duracion))))
            if creado:
                progreso.update(porcentaje,
                                '%s\nTiempo restante: %ds' % (mensaje, restante))

            if time.time() >= proximo:
                estado = comprobar_pin(check, pin)
                codigo = estado.get('codigo') or ''
                if codigo in ('PIN_EXPIRED', 'PIN_INVALID'):
                    raise AllDebridPinError(
                        'El PIN de AllDebrid ha caducado o no es válido. Vuelve a '
                        'pulsar "Vincular AllDebrid con PIN".', esperada=True)
                if estado.get('error'):
                    xbmc.log('[Gaia] AllDebrid PIN: %s' % estado['error'],
                             xbmc.LOGDEBUG)
                if estado.get('activated'):
                    apikey = str(estado.get('apikey') or '').strip()
                    if not apikey:
                        raise AllDebridPinError(
                            'AllDebrid no devolvió la API Key tras activar el PIN.')
                    if guardar_apikey:
                        try:
                            guardar_apikey('alldebrid_apikey', apikey)
                        except Exception as exc:
                            raise AllDebridPinError(
                                'No se pudo guardar la API Key de AllDebrid: %s' % exc)
                    if creado:
                        progreso.update(100, 'Cuenta de AllDebrid vinculada.')
                    xbmcgui.Dialog().notification(
                        'Gaia - AllDebrid',
                        'Cuenta de AllDebrid vinculada correctamente.',
                        xbmcgui.NOTIFICATION_INFO, 5000)
                    return True
                proximo = time.time() + INTERVALO_PIN

            xbmc.sleep(1000)

        raise AllDebridPinError(
            'El PIN de AllDebrid ha caducado. Vuelve a pulsar '
            '"Vincular AllDebrid con PIN".', esperada=True)
    finally:
        try:
            progreso.close()
        except Exception:
            pass


class AllDebridClient(object):
    """Acceso a magnets completados, enlaces guardados y desenlace de links."""

    def __init__(self, apikey, cache_minutes=15, profile=None):
        self.apikey = (apikey or '').strip()
        try:
            self.cache_minutes = max(0, int(cache_minutes))
        except (TypeError, ValueError):
            self.cache_minutes = 15
        self.cache_path = os.path.join(profile, 'alldebrid_cache.json') if profile else ''
        self.origen_cache = False
        self.origen_cache_files = False

    # ------------------------------------------------------------------ red

    def _peticion(self, endpoint, extra=None, usar_cache=False, metodo='GET'):
        """Llama a un endpoint vigente y devuelve su bloque 'data'."""
        if not self.apikey:
            mensaje = 'Falta la API Key de AllDebrid. Configúrala en los ajustes de Gaia.'
            _avisar(mensaje)
            raise AllDebridError(mensaje)

        parametros = dict(extra or {})
        parametros['agent'] = AGENT
        parametros['apikey'] = self.apikey
        consulta = urllib.parse.urlencode(parametros, doseq=True)
        clave_cache = '%s %s?%s' % (
            metodo, endpoint,
            urllib.parse.urlencode(sorted(parametros.items()), doseq=True))

        self.origen_cache = False
        self.origen_cache_files = False
        if usar_cache:
            guardado = self._leer_cache(clave_cache)
            if guardado is not None:
                self.origen_cache = True
                if endpoint == ARCHIVOS_MAGNETS:
                    self.origen_cache_files = True
                xbmc.log('[Gaia] AllDebrid %s desde caché local' % endpoint,
                         xbmc.LOGINFO)
                return guardado
        xbmc.log('[Gaia] AllDebrid %s en vivo' % endpoint, xbmc.LOGINFO)

        url = '%s/%s?%s' % (API_BASE, endpoint.lstrip('/'), consulta)
        cabeceras = {
            'User-Agent': AGENT,
            'Accept': 'application/json',
            'Authorization': 'Bearer %s' % self.apikey,
        }
        cuerpo = None
        if metodo == 'POST':
            cuerpo = urllib.parse.urlencode(extra or {}, doseq=True).encode('utf-8')
            cabeceras['Content-Type'] = 'application/x-www-form-urlencoded'
        peticion = urllib.request.Request(url, data=cuerpo, headers=cabeceras, method=metodo)

        try:
            with urllib.request.urlopen(peticion, timeout=20) as respuesta:
                contenido = respuesta.read().decode('utf-8')
            datos = json.loads(contenido)
        except (urllib.error.HTTPError, urllib.error.URLError, OSError) as exc:
            mensaje = 'No se pudo conectar con AllDebrid. Revisa la conexión e inténtalo de nuevo.'
            xbmc.log('[Gaia] Error de red: %s' % exc, xbmc.LOGERROR)
            _avisar(mensaje)
            raise AllDebridError(mensaje)
        except (ValueError, UnicodeError) as exc:
            mensaje = 'AllDebrid devolvió una respuesta inesperada. Inténtalo de nuevo.'
            xbmc.log('[Gaia] Respuesta no válida: %s' % exc, xbmc.LOGERROR)
            _avisar(mensaje)
            raise AllDebridError(mensaje)

        if not isinstance(datos, dict):
            mensaje = 'AllDebrid devolvió una respuesta inesperada. Inténtalo de nuevo.'
            _avisar(mensaje)
            raise AllDebridError(mensaje)

        if datos.get('status') != 'success':
            error = datos.get('error') or {}
            if isinstance(error, dict):
                mensaje = error.get('message') or error.get('code') or ''
                codigo = str(error.get('code') or '')
            elif isinstance(error, str):
                mensaje = error
                codigo = ''
            else:
                mensaje = str(datos.get('message') or '')
                codigo = ''
            if not mensaje:
                mensaje = 'AllDebrid devolvió un error sin mensaje (código: %s).' % (
                    codigo or 'desconocido')
            xbmc.log('[Gaia] AllDebrid %s -> %s: %s' % (endpoint, codigo, mensaje),
                     xbmc.LOGERROR)
            _avisar(mensaje)
            raise AllDebridError(mensaje)

        datos_utiles = datos.get('data') or {}
        if usar_cache:
            self._escribir_cache(clave_cache, datos_utiles)
        return datos_utiles

    # ---------------------------------------------------------------- caché

    def _leer_cache(self, clave):
        """Devuelve los datos guardados si no han caducado."""
        if not self.cache_path or self.cache_minutes <= 0:
            return None
        try:
            with open(self.cache_path, 'r', encoding='utf-8') as archivo:
                cache = json.load(archivo)
            entrada = cache.get(clave) or {}
            if time.time() - float(entrada.get('hora', 0)) < self.cache_minutes * 60:
                return entrada.get('datos')
        except (OSError, ValueError, TypeError, AttributeError):
            pass
        return None

    def _escribir_cache(self, clave, datos):
        """Guarda una copia local del listado para no saturar la API."""
        if not self.cache_path or self.cache_minutes <= 0:
            return
        try:
            directorio = os.path.dirname(self.cache_path)
            if directorio:
                os.makedirs(directorio, exist_ok=True)
            try:
                with open(self.cache_path, 'r', encoding='utf-8') as archivo:
                    cache = json.load(archivo)
            except (OSError, ValueError):
                cache = {}
            if not isinstance(cache, dict):
                cache = {}
            cache[clave] = {'hora': time.time(), 'datos': datos}
            with open(self.cache_path, 'w', encoding='utf-8') as archivo:
                json.dump(cache, archivo)
        except OSError as exc:
            xbmc.log('[Gaia] No se pudo escribir la caché: %s' % exc, xbmc.LOGDEBUG)

    def invalidar_cache(self):
        """Borra el listado local guardado de magnets y enlaces."""
        if not self.cache_path:
            return False
        try:
            os.remove(self.cache_path)
            xbmc.log('[Gaia] Caché de AllDebrid eliminada: %s' % self.cache_path,
                     xbmc.LOGINFO)
            return True
        except OSError:
            return False

    # -------------------------------------------------------------- magnets

    @staticmethod
    def _es_video(nombre):
        return str(nombre or '').lower().endswith(VIDEO_EXTENSIONS)

    @classmethod
    def _recoger_archivos(cls, entradas, resultado, link_padre=''):
        """Aplana el árbol de archivos 'n'/'e' que usa AllDebrid v4."""
        if isinstance(entradas, dict):
            entradas = [entradas]
        for entrada in entradas or []:
            if not isinstance(entrada, dict):
                continue
            nombre = entrada.get('n') or entrada.get('name') or ''
            hijos = entrada.get('e') or entrada.get('files')
            if hijos:
                cls._recoger_archivos(hijos, resultado, link_padre)
            elif cls._es_video(nombre):
                resultado.append({
                    'name': nombre,
                    'link': entrada.get('l') or entrada.get('link') or link_padre,
                    'size': entrada.get('s') or entrada.get('size') or 0,
                })

    @staticmethod
    def _esta_listo(magnet):
        estado = str(magnet.get('status') or '').lower()
        return estado in READY_STATUSES or magnet.get('statusCode') == 4

    def get_completed_magnets(self):
        """Devuelve los magnets terminados con sus archivos de vídeo."""
        datos = self._peticion(ESTADO_MAGNETS, {'status': 'ready'}, usar_cache=True)
        datos_origen = self.origen_cache
        magnets = _lista(datos.get('magnets'))
        xbmc.log('[Gaia] Magnets recibidos: %d (%s)' % (
            len(magnets), 'caché' if datos_origen else 'en vivo'), xbmc.LOGINFO)

        resultado = []
        sin_archivos = []
        for magnet in magnets:
            if not isinstance(magnet, dict) or not self._esta_listo(magnet):
                continue

            archivos = []
            enlaces = magnet.get('links') or []
            if isinstance(enlaces, dict):
                enlaces = [enlaces]

            # Compatibilidad con respuestas que aún traen enlaces en el estado.
            for enlace in enlaces:
                if not isinstance(enlace, dict):
                    continue
                propio = enlace.get('link') or enlace.get('l') or ''
                self._recoger_archivos(enlace.get('files'), archivos, propio)
                nombre = enlace.get('filename') or enlace.get('n') or magnet.get('filename') or ''
                if not enlace.get('files') and self._es_video(nombre):
                    archivos.append({
                        'name': nombre,
                        'link': propio,
                        'size': enlace.get('size') or enlace.get('s') or 0,
                    })

            # Compatibilidad con respuestas que traen 'files' en el magnet.
            self._recoger_archivos(magnet.get('files'), archivos)

            resultado.append({
                'id': magnet.get('id'),
                'name': magnet.get('filename') or 'Magnet %s' % magnet.get('id', ''),
                'files': archivos,
                'link': magnet.get('link') or '',
                'size': magnet.get('size') or 0,
            })
            if not archivos and magnet.get('id') is not None:
                sin_archivos.append(magnet['id'])

        # La API vigente entrega los archivos solo en /v4/magnet/files.
        if sin_archivos:
            try:
                por_id = self._files_por_magnet(sin_archivos)
            except AllDebridError as exc:
                xbmc.log('[Gaia] No se pudieron obtener los archivos: %s' % exc,
                         xbmc.LOGWARNING)
                por_id = {}
            for magnet in resultado:
                if not magnet['files']:
                    magnet['files'] = por_id.get(str(magnet.get('id')), [])

        # Último recurso: el propio magnet apunta a un archivo de vídeo.
        # No exigimos extensión: los nombres de AllDebrid suelen ser la
        # etiqueta del release ('[4k 2160p][Esp]') sin extensión.
        for magnet in resultado:
            if not magnet['files'] and magnet['link']:
                magnet['files'] = [{'name': magnet['name'], 'link': magnet['link'],
                                    'size': magnet['size']}]

        utilizables = [{'id': magnet['id'], 'name': magnet['name'], 'files': magnet['files']}
                       for magnet in resultado if magnet['files']]
        xbmc.log('[Gaia] Magnets listos: %d; con archivos de vídeo: %d; '
                 'archivos desde caché: %s' % (
                     len(resultado), len(utilizables),
                     'sí' if self.origen_cache_files else 'no'), xbmc.LOGINFO)
        return utilizables

    def _files_por_magnet(self, identificadores):
        """Consulta /v4/magnet/files para obtener los archivos de los magnets."""
        datos = self._peticion(ARCHIVOS_MAGNETS, {'id[]': identificadores},
                               usar_cache=True, metodo='POST')
        magnets = _lista(datos.get('magnets'))

        resultado = {}
        for magnet in magnets:
            if not isinstance(magnet, dict):
                continue
            archivos = []
            self._recoger_archivos(magnet.get('files'), archivos)
            resultado[str(magnet.get('id'))] = archivos
        return resultado

    # ------------------------------------------------------ enlaces guardados

    def get_saved_links(self):
        """Devuelve los enlaces guardados por el usuario que son vídeos."""
        datos = self._peticion(ENLACES_GUARDADOS, usar_cache=True)
        enlaces = _lista(datos.get('links'))

        resultado = []
        for enlace in enlaces:
            if not isinstance(enlace, dict):
                continue
            nombre = enlace.get('filename') or ''
            if self._es_video(nombre):
                resultado.append({
                    'name': nombre,
                    'link': enlace.get('link') or '',
                    'size': enlace.get('size') or 0,
                })
        return resultado

    # --------------------------------------------------------------unlock

    def unlock_link(self, link):
        """Desbloquea un enlace de AllDebrid y devuelve la URL directa."""
        datos = self._peticion(DESBLOQUEAR, {'link': link}, metodo='POST')
        directo = datos.get('link') or datos.get('url') or ''
        if not directo:
            calidades = datos.get('streams') or []
            if calidades and isinstance(calidades, list) and isinstance(calidades[0], dict):
                directo = calidades[0].get('link') or ''
        if not directo:
            mensaje = 'AllDebrid no devolvió una URL reproducible para este enlace.'
            _avisar(mensaje)
            raise AllDebridError(mensaje)
        return directo
