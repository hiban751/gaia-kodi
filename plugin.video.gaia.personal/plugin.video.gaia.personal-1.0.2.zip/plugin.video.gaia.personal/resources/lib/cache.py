# -*- coding: utf-8 -*-
"""Caché persistente de Gaia basada en SQLite.

La base de datos se crea dentro del perfil del addon, por lo que sobrevive a
reinicios de Kodi y funciona igual en Android, Fire TV y PC. Solamente usa
módulos de la biblioteca estándar (sqlite3, json, os y time).
"""

import json
import os
import sqlite3
import time

import xbmc
import xbmcvfs

# Los metadatos de TMDB apenas cambian: se guardan hasta 7 días.
TTL_ESTABLE = 7 * 24 * 60


class Cache(object):
    """Almacena respuestas JSON con un tiempo de vida por entrada."""

    def __init__(self, profile, minutos=15):
        try:
            self.minutos = max(0, int(minutos))
        except (TypeError, ValueError):
            self.minutos = 15

        self.ruta = ''
        try:
            carpeta = xbmcvfs.translatePath(profile)
            xbmcvfs.mkdirs(carpeta)
            self.aciertos = 0
            self.lecturas = 0
            self.ruta = os.path.join(carpeta, 'gaia_cache.db')
            with sqlite3.connect(self.ruta, timeout=5) as conexion:
                conexion.execute('PRAGMA busy_timeout=5000')
                conexion.execute(
                    'CREATE TABLE IF NOT EXISTS gaia_cache ('
                    'seccion TEXT NOT NULL, clave TEXT NOT NULL, '
                    'valor TEXT NOT NULL, creado REAL NOT NULL, '
                    'PRIMARY KEY (seccion, clave))')
                conexion.execute(
                    'CREATE TABLE IF NOT EXISTS gaia_resume ('
                    'clave TEXT NOT NULL PRIMARY KEY, posicion REAL NOT NULL, '
                    'duracion REAL NOT NULL, actualizado REAL NOT NULL)')
            self.limpiar()
        except (sqlite3.Error, OSError, TypeError, AttributeError) as exc:
            xbmc.log('[Gaia] Caché no disponible: %s' % exc, xbmc.LOGWARNING)
            self.ruta = ''

    def _ttl(self, minutos):
        """Resuelve el TTL en minutos solicitado."""
        if minutos is None:
            return self.minutos
        try:
            return max(0, int(minutos))
        except (TypeError, ValueError):
            return self.minutos

    def get(self, seccion, clave, minutos=None):
        """Devuelve el valor guardado si no ha caducado, o None."""
        ttl = self._ttl(minutos)
        if not self.ruta or ttl <= 0:
            return None
        self.lecturas = getattr(self, 'lecturas', 0) + 1
        try:
            with sqlite3.connect(self.ruta, timeout=5) as conexion:
                fila = conexion.execute(
                    'SELECT valor, creado FROM gaia_cache WHERE seccion=? AND clave=?',
                    (str(seccion), str(clave))).fetchone()
            if fila and time.time() - float(fila[1]) < ttl * 60:
                self.aciertos = getattr(self, 'aciertos', 0) + 1
                xbmc.log('[Gaia] Caché SQLite %s: acierto' % seccion, xbmc.LOGDEBUG)
                return json.loads(fila[0])
            xbmc.log('[Gaia] Caché SQLite %s: sin entrada vigente' % seccion,
                     xbmc.LOGDEBUG)
        except (sqlite3.Error, ValueError, TypeError) as exc:
            xbmc.log('[Gaia] Error leyendo la caché: %s' % exc, xbmc.LOGDEBUG)
        return None

    def set(self, seccion, clave, valor, minutos=None):
        """Guarda un valor JSON con la hora actual."""
        ttl = self._ttl(minutos)
        if not self.ruta or ttl <= 0:
            return
        try:
            with sqlite3.connect(self.ruta, timeout=5) as conexion:
                conexion.execute(
                    'INSERT OR REPLACE INTO gaia_cache '
                    '(seccion, clave, valor, creado) VALUES (?, ?, ?, ?)',
                    (str(seccion), str(clave), json.dumps(valor), time.time()))
        except (sqlite3.Error, TypeError, ValueError) as exc:
            xbmc.log('[Gaia] Error escribiendo la caché: %s' % exc, xbmc.LOGDEBUG)

    def get_resume(self, clave):
        """Devuelve el punto de reproducción guardado para una clave estable."""
        if not self.ruta or not clave:
            return None
        try:
            with sqlite3.connect(self.ruta, timeout=5) as conexion:
                fila = conexion.execute(
                    'SELECT posicion, duracion, actualizado FROM gaia_resume '
                    'WHERE clave=?', (str(clave),)).fetchone()
            if fila:
                return {'posicion': float(fila[0] or 0),
                        'duracion': float(fila[1] or 0),
                        'actualizado': float(fila[2] or 0)}
        except (sqlite3.Error, TypeError, ValueError) as exc:
            xbmc.log('[Gaia] Error leyendo el resume: %s' % exc, xbmc.LOGDEBUG)
        return None

    def set_resume(self, clave, posicion, duracion=0):
        """Guarda posición y duración sin aplicar el TTL de la caché normal."""
        if not self.ruta or not clave:
            return
        try:
            with sqlite3.connect(self.ruta, timeout=5) as conexion:
                conexion.execute(
                    'INSERT OR REPLACE INTO gaia_resume '
                    '(clave, posicion, duracion, actualizado) VALUES (?, ?, ?, ?)',
                    (str(clave), max(0.0, float(posicion or 0)),
                     max(0.0, float(duracion or 0)), time.time()))
        except (sqlite3.Error, TypeError, ValueError) as exc:
            xbmc.log('[Gaia] Error guardando el resume: %s' % exc, xbmc.LOGDEBUG)

    def delete_resume(self, clave):
        """Elimina el punto guardado cuando termina la película."""
        if not self.ruta or not clave:
            return
        try:
            with sqlite3.connect(self.ruta, timeout=5) as conexion:
                conexion.execute('DELETE FROM gaia_resume WHERE clave=?', (str(clave),))
        except (sqlite3.Error, TypeError, ValueError) as exc:
            xbmc.log('[Gaia] Error borrando el resume: %s' % exc, xbmc.LOGDEBUG)

    def limpiar(self, minutos=TTL_ESTABLE):
        """Elimina entradas más antiguas que el TTL estable."""
        if not self.ruta:
            return
        try:
            limite = time.time() - self._ttl(minutos) * 60
            with sqlite3.connect(self.ruta, timeout=5) as conexion:
                conexion.execute('DELETE FROM gaia_cache WHERE creado < ?', (limite,))
        except sqlite3.Error as exc:
            xbmc.log('[Gaia] Error limpiando la caché: %s' % exc, xbmc.LOGDEBUG)

    def invalidar_catalogo(self):
        """Borra de SQLite el catálogo y los metadatos derivados de los magnets."""
        if not self.ruta:
            return 0
        borrados = 0
        try:
            with sqlite3.connect(self.ruta, timeout=5) as conexion:
                cursor = conexion.execute('DELETE FROM gaia_cache')
                borrados = cursor.rowcount
            xbmc.log('[Gaia] Caché SQLite de catálogo invalidada: %d entradas' % borrados,
                     xbmc.LOGINFO)
        except sqlite3.Error as exc:
            xbmc.log('[Gaia] Error invalidando la caché SQLite: %s' % exc,
                     xbmc.LOGWARNING)
        return borrados

    def obtener_ids_magnets(self):
        """Devuelve el conjunto de IDs de magnets guardado en SQLite."""
        if not self.ruta:
            return None
        try:
            with sqlite3.connect(self.ruta, timeout=5) as conexion:
                fila = conexion.execute(
                    'SELECT valor FROM gaia_cache WHERE seccion=? AND clave=?',
                    ('catalogo', 'magnet_ids')).fetchone()
            if fila:
                return set(json.loads(fila[0]))
        except (sqlite3.Error, TypeError, ValueError) as exc:
            xbmc.log('[Gaia] No se pudieron leer los IDs cacheados: %s' % exc,
                     xbmc.LOGDEBUG)
        return None

    def guardar_ids_magnets(self, ids):
        """Guarda el conjunto actual de IDs de magnets en SQLite."""
        if not self.ruta:
            return
        self.set('catalogo', 'magnet_ids', sorted(str(i) for i in ids), minutos=TTL_ESTABLE)

