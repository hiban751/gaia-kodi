# -*- coding: utf-8 -*-
"""Recursos del addon Gaia."""
