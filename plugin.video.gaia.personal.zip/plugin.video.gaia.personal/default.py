# -*- coding: utf-8 -*-
"""Punto de entrada del addon Gaia para Kodi 20/21 (Python 3).

Los vídeos se leen de AllDebrid y se enriquecen con metadatos de TMDB
guardados en una caché SQLite local. Todo funciona sin dependencias extra.
"""

import json
import os
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import xbmcplugin

from resources.lib import alldebrid, cache as cache_lib, parser, tmdb, trakt

ADDON = xbmcaddon.Addon()
TRAKT_API_BASE = 'https://api.trakt.tv'
TRAKT_URL_ACTIVACION = 'https://auth.trakt.tv/activate'
TRAKT_USER_AGENT = 'GaiaKodi/1.0'


def _handle_desde_argv():
    """Devuelve el handle de plugin; -1 cuando se ejecuta como script."""
    try:
        return int(sys.argv[1])
    except (IndexError, TypeError, ValueError):
        return -1


HANDLE = _handle_desde_argv()
ARGUMENTOS_CRUDOS = sys.argv[2] if len(sys.argv) > 2 else ''
ARGUMENTOS = dict(urllib.parse.parse_qsl(ARGUMENTOS_CRUDOS.lstrip('?')))
ACCION_SCRIPT = (sys.argv[1] if len(sys.argv) > 1 and
                 sys.argv[1] in ('trakt_auth', 'trakt_revoke',
                                 'alldebrid_pin', 'alldebrid_revoke',
                                 'refresh_catalog') else '')

CATEGORIAS = (
    ('peliculas', 'Películas', 'movies'),
    ('series', 'Series', 'tvshows'),
    ('anime', 'Anime', 'tvshows'),
    ('documentales', 'Documentales', 'movies'),
)

CACHE = None
TMDB = None
_METADATOS = {}
_TEMPORADAS = {}
_TRAKT_VISTAS = None
_TRAKT_PROGRESOS = None
_TRAKT_PROGRESOS_PRECARGA = False
_MONITORES = []


def url_interna(**parametros):
    """Construye la URL de un elemento del plugin."""
    return '%s?%s' % (sys.argv[0], urllib.parse.urlencode(parametros))


def ruta_perfil():
    """Devuelve la ruta real del perfil del addon (special:// -> sistema)."""
    perfil = ADDON.getAddonInfo('profile')
    if hasattr(xbmcvfs, 'translatePath'):
        return xbmcvfs.translatePath(perfil)
    return xbmc.translatePath(perfil)


def ruta_addon():
    """Devuelve la ruta real del addon (special:// -> sistema)."""
    try:
        base = ADDON.getAddonInfo('path')
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return ''
    try:
        if hasattr(xbmcvfs, 'translatePath'):
            return xbmcvfs.translatePath(base)
        return xbmc.translatePath(base)
    except (AttributeError, OSError, TypeError, ValueError):
        return base


def ruta_recurso(relativa):
    """Resuelve un recurso local del addon con separadores del sistema."""
    base = ruta_addon()
    if not base:
        return ''
    return os.path.join(base, str(relativa).replace('/', os.sep))


def existe_recurso(ruta):
    """Comprueba un recurso usando Kodi y, si falla, el sistema de archivos."""
    if not ruta:
        return False
    try:
        if hasattr(xbmcvfs, 'exists') and xbmcvfs.exists(ruta):
            return True
    except (AttributeError, OSError, TypeError, ValueError):
        pass
    try:
        return os.path.isfile(ruta)
    except (OSError, TypeError, ValueError):
        return False


def arte_categoria(categoria):
    """Devuelve el arte local de una categoría con fallback seguro."""
    icono_local = ruta_recurso('resources/media/%s.png' % categoria)
    if not existe_recurso(icono_local):
        iconos = {'peliculas': 'DefaultMovies.png',
                  'series': 'DefaultTVShows.png',
                  'anime': 'DefaultTVShows.png',
                  'documentales': 'DefaultMovies.png'}
        icono_local = iconos.get(categoria, 'DefaultFolder.png')
    fanart = ruta_recurso('resources/fanart.jpg')
    if not existe_recurso(fanart):
        fanart = ''
    return {'icon': icono_local, 'thumb': icono_local, 'fanart': fanart}


def minutos_cache():
    """Lee los minutos de caché configurados en Gaia."""
    try:
        return ADDON.getSettingInt('cache_minutes')
    except (TypeError, ValueError, AttributeError):
        try:
            return int(ADDON.getSetting('cache_minutes') or 15)
        except (TypeError, ValueError):
            return 15


def configuracion_booleana(clave):
    """Lee un ajuste booleano con compatibilidad con Kodi 19+."""
    try:
        return bool(ADDON.getSettingBool(clave))
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return str(ADDON.getSetting(clave) or '').lower() in ('true', '1', 'yes')


def mensaje_trakt(identificador, defecto):
    """Devuelve un texto traducido del addon, con respaldo en español."""
    try:
        return ADDON.getLocalizedString(identificador) or defecto
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return defecto


def crear_cliente_trakt():
    """Crea el cliente de Trakt usando únicamente el Client ID configurado."""
    return trakt.TraktClient(
        client_id=str(ADDON.getSetting('trakt_client_id') or ''),
        profile=ruta_perfil(),
    )


def obtener_trakt():
    """Devuelve un cliente Trakt listo cuando está activado y autorizado."""
    if not configuracion_booleana('trakt_enabled'):
        return None
    cliente = crear_cliente_trakt()
    try:
        return cliente if cliente.esta_autorizado() else None
    except Exception as exc:
        xbmc.log('[Gaia] Trakt no está disponible: %s' % exc, xbmc.LOGDEBUG)
        return None


def precargar_progresos_trakt():
    """Descarga el progreso de Trakt en segundo plano al abrir un listado."""
    global _TRAKT_PROGRESOS_PRECARGA
    if _TRAKT_PROGRESOS_PRECARGA:
        return
    _TRAKT_PROGRESOS_PRECARGA = True
    cliente = obtener_trakt()
    if cliente is None:
        return

    def tarea():
        global _TRAKT_PROGRESOS
        try:
            _TRAKT_PROGRESOS = cliente.progresos_peliculas(
                usar_cache=False, timeout=trakt.TIEMPO_ESPERA_PROGRESO)
        except Exception as exc:
            xbmc.log('[Gaia] No se pudo precargar el progreso de Trakt: %s' % exc,
                     xbmc.LOGDEBUG)
            _TRAKT_PROGRESOS = None

    threading.Thread(target=tarea, name='GaiaTraktProgress', daemon=True).start()


def vistas_trakt():
    """Carga una sola vez por sesión el historial de películas de Trakt."""
    global _TRAKT_VISTAS
    cliente = obtener_trakt()
    if cliente is None:
        return set()
    precargar_progresos_trakt()
    if _TRAKT_VISTAS is None:
        try:
            _TRAKT_VISTAS = cliente.claves_peliculas_vistas()
        except Exception as exc:
            xbmc.log('[Gaia] No se pudo leer el historial de Trakt: %s' % exc,
                     xbmc.LOGDEBUG)
            _TRAKT_VISTAS = set()
    return _TRAKT_VISTAS


def trakt_progresos(usar_cache=True, timeout=None):
    """Devuelve los progresos de Trakt cacheados por session."""
    global _TRAKT_PROGRESOS
    if usar_cache and _TRAKT_PROGRESOS is not None:
        return _TRAKT_PROGRESOS
    cliente = obtener_trakt()
    if cliente is None:
        return {}
    try:
        _TRAKT_PROGRESOS = cliente.progresos_peliculas(
            usar_cache=usar_cache, timeout=timeout or trakt.TIEMPO_ESPERA_PROGRESO)
    except Exception as exc:
        xbmc.log('[Gaia] No se pudo leer el progreso de Trakt: %s' % exc,
                 xbmc.LOGDEBUG)
        _TRAKT_PROGRESOS = {}
    return _TRAKT_PROGRESOS


def progreso_trakt(ids):
    """Devuelve el progreso remoto de una película, o {} si no hay datos."""
    cliente = obtener_trakt()
    if cliente is None:
        return {}
    try:
        return cliente.progreso_de_pelicula(
            ids, progresos=trakt_progresos(usar_cache=True))
    except Exception as exc:
        xbmc.log('[Gaia] No se pudo resolver el progreso de Trakt: %s' % exc,
                 xbmc.LOGDEBUG)
        return {}


def crear_cliente():
    """Crea el cliente de AllDebrid con los ajustes actuales de Gaia."""
    return alldebrid.AllDebridClient(
        str(ADDON.getSetting('alldebrid_apikey') or ''),
        cache_minutes=minutos_cache(),
        profile=ruta_perfil(),
    )


def cache_local():
    """Caché SQLite disponible siempre, incluso sin API Key de TMDB."""
    global CACHE
    minutos = minutos_cache()
    if CACHE is None or getattr(CACHE, 'minutos', None) != minutos:
        CACHE = cache_lib.Cache(ruta_perfil(), minutos)
    return CACHE


def obtener_tmdb():
    """Inicializa TMDB y su caché solo cuando hay una API Key configurada."""
    global TMDB
    if TMDB is None:
        apikey = str(ADDON.getSetting('tmdb_apikey') or '').strip()
        if not apikey:
            return None
        TMDB = tmdb.TMDBClient(apikey, cache_local())
    return TMDB


def _entero(valor, defecto=0):
    try:
        return int(valor)
    except (TypeError, ValueError):
        return defecto


def _flotante(valor, defecto=0.0):
    try:
        return float(valor)
    except (TypeError, ValueError):
        return defecto


def formato_tamano(valor):
    """Humaniza un tamaño en bytes para mostrarlo en el selector."""
    try:
        numero = float(valor)
    except (TypeError, ValueError):
        return ''
    if numero <= 0:
        return ''
    unidades = ('B', 'KB', 'MB', 'GB', 'TB')
    indice = 0
    while numero >= 1024 and indice < len(unidades) - 1:
        numero /= 1024.0
        indice += 1
    if unidades[indice] == 'B':
        return '%d B' % int(numero)
    return '%.1f %s' % (numero, unidades[indice])


def nombre_corto(nombre, maximo=46):
    """Recorta un nombre de archivo largo sin perder el sufijo útil."""
    texto = str(nombre or '').strip()
    if len(texto) <= maximo:
        return texto
    return texto[:maximo - 3].rstrip() + '...'


def opcion_de_video(entrada):
    """Construye una opción de reproducción con calidad y tamaño visibles."""
    nombre = entrada.get('filename') or entrada.get('title') or ''
    calidad = parser.extraer_calidad('%s %s' % (entrada.get('title') or '', nombre))
    size = entrada.get('size') or 0
    base = calidad or nombre or 'Predeterminada'
    etiqueta = base
    tamano = formato_tamano(size)
    if tamano:
        etiqueta = '%s (%s)' % (base, tamano)
    return {'enlace': entrada.get('link') or '', 'calidad': calidad,
            'etiqueta': etiqueta, 'nombre': nombre, 'size': size}


def opciones_unicas(fuentes):
    """Distingue opciones que comparten resolución añadiendo nombre/tamaño."""
    conteo = {}
    for opcion in fuentes:
        base = opcion.get('calidad') or opcion.get('etiqueta') or 'Predeterminada'
        conteo[base] = conteo.get(base, 0) + 1

    vistos = {}
    for indice, opcion in enumerate(fuentes, 1):
        base = opcion.get('calidad') or opcion.get('etiqueta') or 'Predeterminada'
        etiqueta = opcion.get('etiqueta') or base
        if conteo[base] > 1:
            detalles = []
            if opcion.get('size'):
                detalles.append(formato_tamano(opcion['size']))
            if opcion.get('nombre'):
                detalles.append(nombre_corto(opcion['nombre']))
            etiqueta = ('%s (%s)' % (base, ' · '.join(detalles))) if detalles else (
                '%s #%d' % (base, indice))
        if etiqueta in vistos:
            vistos[etiqueta] += 1
            etiqueta = '%s #%d' % (etiqueta, vistos[etiqueta])
        else:
            vistos[etiqueta] = 1
        opcion['etiqueta'] = etiqueta
    return fuentes


def url_pelicula(fuentes, titulo, ids=None, clave=None):
    """Serializa las fuentes, la clave de resume y los ids de una película."""
    parametros = {'action': 'play', 'titulo': titulo,
                  'fuentes': json.dumps(fuentes, ensure_ascii=False)}
    clave = clave or clave_resume_de_ids(ids)
    if clave:
        parametros['resume'] = clave
    if ids:
        parametros['trakt'] = json.dumps(ids, ensure_ascii=False)
    return url_interna(**parametros)


def fuentes_de_argumentos(enlace='', crudas='', titulo=''):
    """Lee las fuentes serializadas; acepta también URLs de una sola fuente."""
    fuentes = []
    if crudas:
        try:
            datos = json.loads(crudas)
        except (TypeError, ValueError):
            datos = []
        if isinstance(datos, dict) and datos.get('enlace'):
            datos = [datos]
        if isinstance(datos, list):
            for dato in datos:
                if isinstance(dato, dict) and dato.get('enlace'):
                    fuentes.append(dict(dato))
    if not fuentes and enlace:
        calidad = parser.extraer_calidad(titulo or enlace)
        fuentes.append({'enlace': enlace, 'calidad': calidad,
                        'etiqueta': calidad or 'Predeterminada',
                        'nombre': titulo or '', 'size': 0})
    return fuentes


def ids_trakt_de_entrada(entrada):
    """Reúne título, año, TMDB e IMDb para identificar una película en Trakt."""
    meta = entrada.get('metadata') or {}
    titulo = meta.get('titulo') or entrada.get('title') or ''
    anio = meta.get('anio') or tmdb.extraer_anio(
        '%s %s' % (entrada.get('filename') or '', entrada.get('title') or ''))
    ids = {}
    if titulo:
        ids['titulo'] = titulo
    if anio:
        ids['anio'] = anio
    if meta.get('id'):
        ids['tmdb'] = meta['id']
    if meta.get('imdb'):
        ids['imdb'] = meta['imdb']
    return ids


def ids_trakt_de_argumentos(crudos=''):
    """Lee los identificadores de Trakt serializados en la URL de reproducción."""
    if not crudos:
        return {}
    try:
        datos = json.loads(crudos)
    except (TypeError, ValueError):
        return {}
    return dict(datos) if isinstance(datos, dict) else {}


def coincide_con_vistas(ids, vistas):
    """Comprueba si una película aparece en el historial de Trakt."""
    if not ids or not vistas:
        return False
    claves = trakt.claves_pelicula(titulo=ids.get('titulo'), anio=ids.get('anio'),
                                   tmdb=ids.get('tmdb'), imdb=ids.get('imdb'))
    return bool(claves & set(vistas))


def clave_resume_de_ids(ids):
    """Clave estable compartida por todas las calidades de una película."""
    ids = ids or {}
    if not any(ids.get(campo) for campo in ('tmdb', 'imdb', 'titulo')):
        return ''
    return parser.clave_pelicula(titulo=ids.get('titulo'), anio=ids.get('anio'),
                                 tmdb_id=ids.get('tmdb'), nombre='')


def leer_resume(clave):
    """Lee el punto guardado por Gaia sin depender de Trakt."""
    if not clave:
        return {}
    try:
        return cache_local().get_resume(clave) or {}
    except Exception as exc:
        xbmc.log('[Gaia] No se pudo leer el resume local: %s' % exc, xbmc.LOGDEBUG)
        return {}


def guardar_resume(clave, posicion, duracion):
    """Guarda posición y duración para la próxima sesión."""
    if not clave:
        return
    try:
        cache_local().set_resume(clave, posicion, duracion)
    except Exception as exc:
        xbmc.log('[Gaia] No se pudo guardar el resume local: %s' % exc, xbmc.LOGDEBUG)


def borrar_resume(clave):
    """Limpia el punto guardado cuando termina la película."""
    if not clave:
        return
    try:
        cache_local().delete_resume(clave)
    except Exception as exc:
        xbmc.log('[Gaia] No se pudo borrar el resume local: %s' % exc, xbmc.LOGDEBUG)


def punto_reanudacion(ids, clave):
    """Combina el resume local con el progreso remoto de Trakt."""
    local = leer_resume(clave)
    pos_local = max(0.0, _flotante(local.get('posicion')))
    dur_local = max(0.0, _flotante(local.get('duracion')))
    pct_local = (pos_local * 100.0 / dur_local) if dur_local > 0 else 0.0
    remoto = progreso_trakt(ids) if ids else {}
    pct_remoto = max(0.0, _flotante(remoto.get('progreso')))

    if pct_remoto > pct_local and pct_remoto > 0:
        return {'porcentaje': round(pct_remoto, 1), 'posicion': 0,
                'duracion': 0, 'origen': 'trakt'}
    if pos_local > 0:
        return {'porcentaje': round(pct_local, 1),
                'posicion': int(pos_local), 'duracion': int(dur_local),
                'origen': 'local'}
    return {}


def texto_reanudacion(punto):
    """Texto corto que se añade al selector de calidad."""
    if not punto:
        return ''
    segundos = _entero(punto.get('posicion'))
    if segundos > 0:
        return '%02d:%02d' % (segundos // 60, segundos % 60)
    porcentaje = _flotante(punto.get('porcentaje'))
    return ('%.0f%%' % porcentaje) if porcentaje > 0 else ''


def aplicar_reanudacion(item, punto):
    """Aplica ResumeTime/TotalTime para que Kodi arranque desde el punto guardado."""
    if not punto:
        return
    segundos = _entero(punto.get('posicion'))
    if segundos <= 0:
        return
    item.setProperty('ResumeTime', str(segundos))
    total = _entero(punto.get('duracion'))
    if total > 0:
        item.setProperty('TotalTime', str(total))


class MonitorReproduccion(threading.Thread):
    """Guarda el progreso local y avisa a Trakt mientras dura el vídeo."""
    INTERVALO = 15

    def __init__(self, clave, ids, titulo, punto=None):
        threading.Thread.__init__(self)
        self.name = 'GaiaResume'
        self.clave = clave
        self.ids = ids or {}
        self.titulo = titulo or ''
        self.punto = punto or {}
        self.daemon = False

    def _cliente_trakt(self):
        try:
            return obtener_trakt()
        except Exception:
            return None

    def _porcentaje(self, posicion, duracion):
        if duracion <= 0:
            return 0.0
        return round(min(100.0, max(0.0, posicion * 100.0 / duracion)), 1)

    def _guardar(self, posicion, duracion):
        if duracion <= 0:
            return
        if posicion >= duracion - 15:
            borrar_resume(self.clave)
        elif posicion >= 30:
            guardar_resume(self.clave, int(posicion), int(duracion))

    def _scrobble(self, cliente, accion, progreso):
        if cliente is None or not self.ids:
            return
        try:
            cliente.scrobble(accion, titulo=self.ids.get('titulo') or self.titulo,
                             anio=self.ids.get('anio'), tmdb=self.ids.get('tmdb'),
                             imdb=self.ids.get('imdb'), progreso=progreso)
        except Exception as exc:
            xbmc.log('[Gaia] Trakt scrobble %s: %s' % (accion, exc), xbmc.LOGDEBUG)

    def run(self):
        try:
            self._seguir()
        except Exception as exc:
            xbmc.log('[Gaia] Monitor de reproducción: %s' % exc, xbmc.LOGDEBUG)
        finally:
            try:
                _MONITORES.remove(self)
            except ValueError:
                pass

    def _seguir(self):
        cliente = self._cliente_trakt()
        reproductor = xbmc.Player()
        inicio = time.time()
        inicio_video = 0.0
        ultimo_guardado = 0.0
        pausado = False
        scrobble_iniciado = False
        remoto_aplicado = False
        max_posicion = 0.0
        duracion = 0.0

        while time.time() - inicio < 6 * 3600:
            try:
                reproduciendo = reproductor.isPlayingVideo()
            except RuntimeError:
                reproduciendo = False
            if not reproduciendo:
                if inicio_video:
                    self._guardar(max_posicion, duracion)
                    self._scrobble(cliente, 'stop',
                                   self._porcentaje(max_posicion, duracion))
                    break
                if time.time() - inicio > 30:
                    break
                xbmc.sleep(500)
                continue

            if not inicio_video:
                inicio_video = time.time()

            try:
                duracion = max(0.0, float(reproductor.getTotalTime()))
                posicion = max(0.0, float(reproductor.getTime()))
            except (RuntimeError, TypeError, ValueError):
                posicion = 0.0

            if not remoto_aplicado:
                objetivo = (duracion * _flotante(self.punto.get('porcentaje')) / 100.0
                            if duracion > 0 else 0.0)
                if objetivo > 60 and abs(posicion - objetivo) > 30:
                    try:
                        reproductor.seekTime(objetivo)
                        posicion = max(posicion, objetivo)
                    except Exception as exc:
                        xbmc.log('[Gaia] No se pudo aplicar el progreso de Trakt: %s' % exc,
                                 xbmc.LOGDEBUG)
                remoto_aplicado = True

            max_posicion = max(max_posicion, posicion)
            if not scrobble_iniciado:
                self._scrobble(cliente, 'start', self._porcentaje(posicion, duracion))
                scrobble_iniciado = True

            try:
                esta_pausado = bool(reproductor.isPaused())
            except (AttributeError, RuntimeError):
                esta_pausado = False
            if esta_pausado and not pausado:
                self._guardar(posicion, duracion)
                self._scrobble(cliente, 'pause', self._porcentaje(posicion, duracion))
            elif not esta_pausado and pausado:
                self._scrobble(cliente, 'start', self._porcentaje(posicion, duracion))
            pausado = esta_pausado

            if duracion > 0 and posicion >= duracion - 5:
                borrar_resume(self.clave)
                self._scrobble(cliente, 'stop', 100.0)
                break

            if time.time() - ultimo_guardado >= self.INTERVALO:
                self._guardar(posicion, duracion)
                ultimo_guardado = time.time()

            xbmc.sleep(1000)


def _aplicar_info_tag(tag, datos):
    """Rellena el InfoTag moderno sin depender de que todos sus métodos existan."""
    def poner(metodo, valor):
        if valor in (None, '', 0) or not hasattr(tag, metodo):
            return
        try:
            getattr(tag, metodo)(valor)
        except (TypeError, ValueError, RuntimeError):
            pass

    poner('setTitle', datos.get('title'))
    poner('setPlot', datos.get('plot'))
    poner('setPlotOutline', datos.get('plotoutline'))
    poner('setOriginalTitle', datos.get('originaltitle'))
    poner('setYear', _entero(datos.get('year')) or None)
    poner('setRating', float(datos.get('rating') or 0))
    poner('setSeason', _entero(datos.get('season')) or None)
    poner('setEpisode', _entero(datos.get('episode')) or None)
    poner('setDuration', _entero(datos.get('duration')) or None)
    poner('setPlayCount', _entero(datos.get('playcount')) or None)
    poner('setMediaType', datos.get('mediatype'))
    poner('setTvShowTitle', datos.get('tvshowtitle'))
    poner('setTVShowTitle', datos.get('tvshowtitle'))

    generos = datos.get('genre') or []
    if generos and hasattr(tag, 'setGenres'):
        try:
            tag.setGenres(generos)
        except (TypeError, ValueError, RuntimeError):
            pass


def crear_item(titulo, carpeta=True, info=None, icono='DefaultFolder.png',
                meta=None, thumb=None, visto=False):

    """Crea un ListItem con metadatos, carátulas e InfoTag de Kodi 20/21."""
    texto = str(titulo or 'Sin título')
    datos = dict(info or {})
    datos.setdefault('title', texto)

    meta = meta or {}
    poster = meta.get('poster') or ''
    fanart = meta.get('fanart') or ''
    arte = {'icon': icono, 'thumb': thumb or poster or icono}
    if poster:
        arte['poster'] = poster
    if fanart:
        arte['fanart'] = fanart

    if meta.get('sinopsis'):
        datos.setdefault('plot', meta['sinopsis'])
    if meta.get('anio'):
        datos.setdefault('year', meta['anio'])
    if meta.get('puntuacion'):
        datos.setdefault('rating', meta['puntuacion'])
    if meta.get('generos'):
        datos.setdefault('genre', meta['generos'])
    if meta.get('duracion'):
        datos.setdefault('duration', meta['duracion'])
    if visto:
        datos['playcount'] = 1

    datos = dict((clave, valor) for clave, valor in datos.items()
                 if clave == 'title' or valor not in (None, '', 0))

    item = xbmcgui.ListItem(texto)
    item.setArt(arte)
    item.setInfo('video', datos)

    tag = None
    if hasattr(item, 'getVideoInfoTag'):
        try:
            tag = item.getVideoInfoTag()
        except (AttributeError, RuntimeError):
            tag = None
    if tag is not None:
        _aplicar_info_tag(tag, datos)

    if not carpeta:
        item.setProperty('IsPlayable', 'true')
    return item


def metadata_de(entrada):
    """Busca en TMDB los metadatos de un vídeo; nunca interrumpe la navegación."""
    cliente = obtener_tmdb()
    if cliente is None:
        return None

    titulo = str(entrada.get('title') or '').strip()
    clave = parser.clave_agrupacion(titulo)
    if not clave:
        return None

    anio = tmdb.extraer_anio('%s %s' % (entrada.get('filename', ''), titulo))
    tipos = (('tv', 'movie') if entrada.get('category') in ('series', 'anime')
             else ('movie', 'tv'))

    for tipo in tipos:
        clave_meta = (tipo, clave, anio)
        if clave_meta in _METADATOS:
            encontrado = _METADATOS[clave_meta]
        else:
            encontrado = None
            try:
                encontrado = cliente.buscar(tipo, titulo, anio)
            except tmdb.TMDBError as exc:
                xbmc.log('[Gaia] TMDB sin resultados para %s: %s' % (titulo, exc),
                         xbmc.LOGDEBUG)
            except Exception as exc:
                xbmc.log('[Gaia] TMDB falló para %s: %s' % (titulo, exc), xbmc.LOGDEBUG)
            _METADATOS[clave_meta] = encontrado
        if encontrado:
            return encontrado
    return None


def metadata_temporada(serie_meta, numero):
    """Obtiene (y reutiliza en memoria) los episodios de una temporada."""
    if not serie_meta or not serie_meta.get('id'):
        return None
    clave = ('temporada', serie_meta['id'], numero)
    if clave in _TEMPORADAS:
        return _TEMPORADAS[clave]

    cliente = obtener_tmdb()
    encontrado = None
    if cliente is not None:
        try:
            encontrado = cliente.temporada(serie_meta['id'], numero)
        except Exception as exc:
            xbmc.log('[Gaia] No se pudo leer la temporada %s: %s' % (numero, exc),
                     xbmc.LOGDEBUG)
    _TEMPORADAS[clave] = encontrado
    return encontrado


def enriquecer_catalogo(catalogo):
    """Añade metadata de TMDB y aplica la clasificación por género/país."""
    if obtener_tmdb() is None:
        xbmc.log('[Gaia] TMDB sin API Key: se conserva la clasificación del parser',
                 xbmc.LOGINFO)
        return catalogo
    enriquecidos = 0
    for entrada in catalogo:
        meta = metadata_de(entrada)
        if not meta:
            continue
        enriquecidos += 1
        entrada['metadata'] = meta
        categoria_meta = tmdb.clasificar(meta, meta['tipo'])
        # Un vídeo sin episodio reconocido es película aunque TMDB devuelva
        # un resultado de TV con un título parecido.
        if not (entrada.get('category') == 'peliculas' and categoria_meta == 'series'):
            entrada['category'] = categoria_meta
        # El ID de TMDB es la clave más fiable cuando dos releases tienen
        # títulos distintos (por ejemplo, "La ciudad" y "The City").
        entrada['movie_key'] = parser.clave_pelicula(
            titulo=meta.get('titulo') or entrada['title'],
            anio=meta.get('anio'),
            tmdb_id=meta.get('id'),
            nombre=entrada.get('filename'))
    xbmc.log('[Gaia] TMDB enriqueció %d de %d entradas' % (enriquecidos, len(catalogo)),
             xbmc.LOGINFO)
    return catalogo


def ids_magnets(magnets):
    """Devuelve un conjunto estable de identificadores de magnets."""
    return set(str(magnet.get('id')) for magnet in magnets
               if magnet.get('id') is not None)


def comprobar_cambio_magnets():
    """Compare los IDs actuales con la caché y regenere el catálogo si cambiaron."""
    cliente = crear_cliente()
    try:
        cliente.invalidar_cache()
        magnets = cliente.get_completed_magnets()
    except alldebrid.AllDebridError as exc:
        xbmc.log('[Gaia] No se pudo comprobar el cambio de magnets: %s' % exc,
                 xbmc.LOGDEBUG)
        return False
    actuales = ids_magnets(magnets)
    memoria = cache_local()
    anteriores = memoria.obtener_ids_magnets()
    if anteriores is not None and actuales == anteriores:
        return False
    xbmc.log('[Gaia] Cambio detectado en los magnets: %s, %d ahora' % (
        'sin caché previa' if anteriores is None else str(len(anteriores)), len(actuales)),
        xbmc.LOGINFO)
    memoria.invalidar_catalogo()
    memoria.guardar_ids_magnets(actuales)
    return True


def crear_catalogo():
    """Reúne magnets completados y enlaces guardados en una sola lista."""
    cliente = crear_cliente()
    catalogo = []
    magnets = []

    try:
        cliente.invalidar_cache()
        magnets = cliente.get_completed_magnets()
        for magnet in magnets:
            for archivo in magnet['files']:
                if not archivo.get('link'):
                    continue
                entrada = parser.parsear_video(archivo['name'], magnet['name'])
                entrada['link'] = archivo['link']
                entrada['size'] = archivo.get('size', 0)
                catalogo.append(entrada)
    except alldebrid.AllDebridError as exc:
        xbmc.log('[Gaia] No se pudo leer los magnets: %s' % exc, xbmc.LOGWARNING)

    xbmc.log('[Gaia] Catálogo: %d magnets y %d archivos con enlace' % (
        len(magnets), len(catalogo)), xbmc.LOGINFO)
    xbmc.log('[Gaia] Clasificación del parser: %d películas, %d series, %d anime, '
             '%d documentales' % tuple(
                 sum(1 for entrada in catalogo if entrada['category'] == clave)
                 for clave in ('peliculas', 'series', 'anime', 'documentales')),
             xbmc.LOGINFO)

    try:
        for enlace in cliente.get_saved_links():
            if not enlace.get('link'):
                continue
            entrada = parser.parsear_video(enlace['name'], '')
            entrada['link'] = enlace['link']
            entrada['size'] = enlace.get('size', 0)
            catalogo.append(entrada)
    except alldebrid.AllDebridError as exc:
        xbmc.log('[Gaia] No se pudo leer los enlaces guardados: %s' % exc, xbmc.LOGWARNING)

    catalogo = enriquecer_catalogo(catalogo)
    registrar_cambio_catalogo()
    xbmc.log('[Gaia] Catálogo final: %d entradas, %d películas' % (
        len(catalogo), sum(1 for entrada in catalogo
                           if entrada['category'] == 'peliculas')), xbmc.LOGINFO)
    memoria = cache_local()
    xbmc.log('[Gaia] Caché SQLite: %d lecturas, %d aciertos' % (
        getattr(memoria, 'lecturas', 0), getattr(memoria, 'aciertos', 0)),
        xbmc.LOGINFO)
    return catalogo


def sincronizar_catalogo():
    """Compara los magnets actuales con los cacheados y regenera si hay cambios."""
    cambiado = comprobar_cambio_magnets()
    if cambiado:
        _METADATOS.clear()
        _TEMPORADAS.clear()
    return cambiado


def refresh_catalog():
    """Borra ambas cachés, recarga magnets y refresca el contenedor de Kodi."""
    memoria = cache_local()
    memoria.invalidar_catalogo()
    crear_cliente().invalidar_cache()
    _METADATOS.clear()
    _TEMPORADAS.clear()
    try:
        catalogo = crear_catalogo()
        xbmc.log('[Gaia] Catálogo regenerado: %d entradas' % len(catalogo),
                 xbmc.LOGINFO)
        mensaje = 'Catálogo de Gaia actualizado.'
        nivel = xbmc.LOGINFO
    except Exception as exc:
        xbmc.log('[Gaia] No se pudo refrescar el catálogo: %s' % exc, xbmc.LOGWARNING)
        mensaje = 'No se pudo actualizar el catálogo.'
        nivel = xbmc.LOGWARNING
    icono = (xbmcgui.NOTIFICATION_INFO if nivel == xbmc.LOGINFO
             else xbmcgui.NOTIFICATION_WARNING)
    xbmcgui.Dialog().notification('Gaia', mensaje, icono, 2500)
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception as exc:
        xbmc.log('[Gaia] No se pudo refrescar el contenedor: %s' % exc,
                 xbmc.LOGDEBUG)


def _item_refresco_catalogo():
    """Devuelve el elemento visible de refresco para el menú principal."""
    return crear_item('Actualizar catálogo / Forzar refresco',
                      icono='DefaultAddonsUpdate.png')


def menu_principal():
    """Muestra las cuatro categorías y el acceso a los ajustes."""
    if not str(ADDON.getSetting('alldebrid_apikey') or '').strip():
        xbmcgui.Dialog().notification(
            'Gaia', 'Configura la API Key de AllDebrid para empezar.',
            xbmcgui.NOTIFICATION_WARNING, 5000)
        ADDON.openSettings()
        return

    iconos = {'peliculas': 'DefaultMovies.png', 'series': 'DefaultTVShows.png',
              'anime': 'DefaultTVShows.png', 'documentales': 'DefaultMovies.png'}
    for categoria, etiqueta, _contenido in CATEGORIAS:
        item = crear_item(etiqueta, icono=iconos.get(categoria, 'DefaultFolder.png'))
        item.setArt(arte_categoria(categoria))
        xbmcplugin.addDirectoryItem(HANDLE, url_interna(action='categoria', categoria=categoria),
                                    item, True)

    actualizar = _item_refresco_catalogo()
    xbmcplugin.addDirectoryItem(HANDLE, url_interna(action='refresh_catalog'),
                                actualizar, True)

    ajustes = crear_item('Ajustes de Gaia', icono='DefaultSettings.png')
    xbmcplugin.addDirectoryItem(HANDLE, url_interna(action='ajustes'), ajustes, True)

    sincronizar_catalogo()
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.setPluginCategory(HANDLE, 'Gaia')
    xbmcplugin.endOfDirectory(HANDLE)


def abrir_ajustes():
    ADDON.openSettings()
    xbmcplugin.endOfDirectory(HANDLE)


def listar_categoria(categoria):
    """Lista una categoría: vídeos sueltos o carpetas de serie/anime."""
    catalogo = crear_catalogo()
    elementos = [entrada for entrada in catalogo if entrada['category'] == categoria]
    xbmc.log('[Gaia] Filtro %s: %d entradas de %d en el catálogo' % (
        categoria, len(elementos), len(catalogo)), xbmc.LOGINFO)
    encabezado = dict((clave, etiqueta) for clave, etiqueta, _contenido in CATEGORIAS)

    if categoria in ('series', 'anime'):
        grupos = {}
        for entrada in elementos:
            clave = parser.clave_agrupacion(entrada['title'])
            meta = entrada.get('metadata') or {}
            titulo = meta.get('titulo') or entrada['title'] or 'Sin título'
            if clave not in grupos:
                grupos[clave] = {'titulo': titulo, 'total': 0, 'meta': None}
            if grupos[clave]['meta'] is None and meta:
                grupos[clave]['meta'] = meta
            grupos[clave]['total'] += 1

        for clave in sorted(grupos, key=lambda valor: grupos[valor]['titulo']):
            grupo = grupos[clave]
            item = crear_item(
                '%s (%d)' % (grupo['titulo'], grupo['total']),
                info={'title': grupo['titulo'], 'tvshowtitle': grupo['titulo'],
                      'mediatype': 'tvshow'},
                icono='DefaultTVShows.png', meta=grupo['meta'])
            xbmcplugin.addDirectoryItem(
                HANDLE,
                url_interna(action='serie', categoria=categoria, serie=clave),
                item, True)
    elif categoria == 'peliculas':
        vistas = vistas_trakt()
        grupos = {}
        for entrada in elementos:
            clave = entrada.get('movie_key') or parser.clave_pelicula(
                titulo=entrada['title'], nombre=entrada.get('filename'))
            meta = entrada.get('metadata') or {}
            titulo = meta.get('titulo') or entrada['title'] or 'Sin título'
            if clave not in grupos:
                grupos[clave] = {'titulo': titulo, 'meta': meta, 'fuentes': []}
            elif not grupos[clave]['meta'] and meta:
                grupos[clave]['meta'] = meta
            grupos[clave]['fuentes'].append(entrada)

        for clave in sorted(grupos, key=lambda valor: grupos[valor]['titulo']):
            grupo = grupos[clave]
            grupo['fuentes'].sort(key=lambda dato: (
                str(dato.get('title') or ''),
                _entero(dato.get('season'), 1),
                _entero(dato.get('episode'), 0),
                str(dato.get('filename') or '')))
            fuentes = opciones_unicas([opcion_de_video(entrada)
                                       for entrada in grupo['fuentes']])
            titulo = grupo['titulo']
            ids = ids_trakt_de_entrada(grupo['fuentes'][0])
            etiqueta = '%s (%d)' % (titulo, len(fuentes)) if len(fuentes) > 1 else titulo
            item = crear_item(etiqueta, carpeta=False, icono='DefaultMovies.png',
                              info={'title': titulo, 'mediatype': 'movie'},
                              meta=grupo['meta'], visto=coincide_con_vistas(ids, vistas))
            xbmcplugin.addDirectoryItem(
                HANDLE, url_pelicula(fuentes, titulo, ids, clave=clave), item, False)
    else:
        vistas = vistas_trakt()
        for entrada in sorted(elementos, key=lambda dato: (
                dato.get('metadata') or {}).get('titulo') or dato['title']):
            meta = entrada.get('metadata') or {}
            titulo = meta.get('titulo') or entrada['title'] or 'Sin título'
            ids = ids_trakt_de_entrada(entrada)
            item = crear_item(titulo, carpeta=False, icono='DefaultMovies.png',
                              info={'title': titulo, 'mediatype': 'movie'}, meta=meta,
                              visto=coincide_con_vistas(ids, vistas))
            clave = entrada.get('movie_key') or parser.clave_pelicula(
                titulo=entrada['title'], nombre=entrada.get('filename'))
            parametros = {'action': 'play', 'enlace': entrada['link'],
                          'titulo': entrada['title'], 'resume': clave}
            if ids:
                parametros['trakt'] = json.dumps(ids, ensure_ascii=False)
            xbmcplugin.addDirectoryItem(HANDLE, url_interna(**parametros), item, False)

    contenido = dict((clave, valor) for clave, _etiqueta, valor in CATEGORIAS)
    xbmcplugin.setPluginCategory(HANDLE, encabezado.get(categoria, 'Gaia'))
    xbmcplugin.setContent(HANDLE, contenido.get(categoria, 'videos'))
    xbmcplugin.endOfDirectory(HANDLE)


def registrar_cambio_catalogo():
    """Guarda los IDs en vivo para detectar altas y bajas en próximas visitas."""
    cliente = crear_cliente()
    try:
        cliente.invalidar_cache()
        ids = ids_magnets(cliente.get_completed_magnets())
        memoria = cache_local()
        anteriores = memoria.obtener_ids_magnets()
        memoria.guardar_ids_magnets(ids)
        return anteriores is None or anteriores != ids
    except alldebrid.AllDebridError as exc:
        xbmc.log('[Gaia] No se pudieron registrar los IDs: %s' % exc, xbmc.LOGDEBUG)
        return False


def listar_temporadas(categoria, serie):
    """Muestra las temporadas disponibles de una serie o anime."""
    temporadas = {}
    serie_meta = None
    for entrada in crear_catalogo():
        if (entrada['category'] == categoria and
                parser.clave_agrupacion(entrada['title']) == serie):
            if serie_meta is None:
                serie_meta = entrada.get('metadata')
            numero = entrada['season'] if entrada['season'] is not None else 1
            temporadas[numero] = temporadas.get(numero, 0) + 1

    titulo_serie = (serie_meta or {}).get('titulo') or serie
    for numero in sorted(temporadas):
        temporada_meta = metadata_temporada(serie_meta, numero) or {}
        if temporada_meta and not temporada_meta.get('fanart') and serie_meta:
            temporada_meta = dict(temporada_meta)
            temporada_meta['fanart'] = serie_meta.get('fanart') or ''
        nombre = temporada_meta.get('nombre') or 'Temporada %d' % numero
        item = crear_item(
            '%s (%d)' % (nombre, temporadas[numero]),
            info={'title': nombre, 'tvshowtitle': titulo_serie, 'season': numero,
                  'mediatype': 'season'},
            icono='DefaultTVShows.png', meta=temporada_meta)
        xbmcplugin.addDirectoryItem(
            HANDLE,
            url_interna(action='temporada', categoria=categoria, serie=serie,
                        temporada=numero),
            item, True)

    xbmcplugin.setPluginCategory(HANDLE, 'Temporadas de %s' % titulo_serie)
    xbmcplugin.setContent(HANDLE, 'seasons')
    xbmcplugin.endOfDirectory(HANDLE)


def listar_episodios(categoria, serie, temporada):
    """Muestra los episodios reproducibles de una temporada."""
    numero_temporada = _entero(temporada, 1) or 1
    catalogo = crear_catalogo()
    serie_meta = None
    episodios = []
    for entrada in catalogo:
        if (entrada['category'] == categoria and
                parser.clave_agrupacion(entrada['title']) == serie and
                (entrada['season'] if entrada['season'] is not None else 1) == numero_temporada):
            if serie_meta is None:
                serie_meta = entrada.get('metadata')
            episodios.append(entrada)

    titulo_serie = (serie_meta or {}).get('titulo') or serie
    temporada_meta = metadata_temporada(serie_meta, numero_temporada) or {}
    episodios_tmdb = temporada_meta.get('episodios') or {}

    for entrada in sorted(episodios, key=lambda dato: (
            _entero(dato.get('season'), numero_temporada),
            _entero(dato.get('episode'), 0),
            str(dato.get('title') or ''), str(dato.get('filename') or ''))):
        numero = entrada['episode']
        episodio_meta = episodios_tmdb.get(numero) or {}
        nombre_tmdb = episodio_meta.get('titulo') or ''
        titulo = ('%dx%02d - %s' % (numero_temporada, numero, nombre_tmdb)) if nombre_tmdb else (
            ('%dx%02d' % (numero_temporada, numero)) if numero else entrada['title'])

        meta = None
        thumb = None
        if episodio_meta:
            meta = dict(episodio_meta)
            meta['poster'] = temporada_meta.get('poster') or (serie_meta or {}).get('poster') or ''
            meta['fanart'] = (serie_meta or {}).get('fanart') or ''
            thumb = episodio_meta.get('still') or meta['poster'] or None

        info = {'title': nombre_tmdb or titulo, 'tvshowtitle': titulo_serie,
                'season': numero_temporada, 'episode': numero or 0,
                'mediatype': 'episode'}
        item = crear_item(titulo, carpeta=False, info=info, icono='DefaultVideo.png',
                          meta=meta, thumb=thumb)
        xbmcplugin.addDirectoryItem(
            HANDLE,
            url_interna(action='play', enlace=entrada['link'], titulo=titulo),
            item, False)

    xbmcplugin.setPluginCategory(HANDLE, '%s - Temporada %d' % (titulo_serie, numero_temporada))
    xbmcplugin.setContent(HANDLE, 'episodes')
    xbmcplugin.endOfDirectory(HANDLE)


def reproducir(enlace='', titulo='', fuentes_crudas='', trakt_crudo='', resume=''):
    """Reproduce una película, permitiendo elegir entre varias calidades."""
    global _MONITORES
    fuentes = fuentes_de_argumentos(enlace, fuentes_crudas, titulo)
    item = crear_item(titulo, carpeta=False, icono='DefaultVideo.png',
                      info={'title': titulo})
    ids = ids_trakt_de_argumentos(trakt_crudo)
    clave = resume or clave_resume_de_ids(ids)

    if not fuentes:
        xbmcgui.Dialog().notification('Gaia', 'Este vídeo no tiene enlace disponible.',
                                      xbmcgui.NOTIFICATION_ERROR, 5000)
        xbmcplugin.setResolvedUrl(HANDLE, False, item)
        return

    punto = punto_reanudacion(ids, clave)
    etiqueta_resume = texto_reanudacion(punto)
    fuente = fuentes[0]
    if len(fuentes) > 1:
        opciones = [str(opcion.get('etiqueta') or 'Opción %d' % (indice + 1))
                    for indice, opcion in enumerate(fuentes)]
        if etiqueta_resume:
            opciones = ['%s · Reanudar %s' % (opcion, etiqueta_resume)
                        for opcion in opciones]
        seleccion = xbmcgui.Dialog().select('Calidad de %s' % (titulo or 'vídeo'), opciones)
        if seleccion is None or seleccion < 0 or seleccion >= len(fuentes):
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        fuente = fuentes[seleccion]

    enlace = fuente.get('enlace') or ''
    if not enlace:
        xbmcgui.Dialog().notification('Gaia', 'Este vídeo no tiene enlace disponible.',
                                      xbmcgui.NOTIFICATION_ERROR, 5000)
        xbmcplugin.setResolvedUrl(HANDLE, False, item)
        return

    try:
        directo = crear_cliente().unlock_link(enlace)
    except alldebrid.AllDebridError:
        xbmcplugin.setResolvedUrl(HANDLE, False, item)
        return

    aplicar_reanudacion(item, punto)
    item.setPath(directo)
    xbmcplugin.setResolvedUrl(HANDLE, True, item)
    if clave:
        monitor = MonitorReproduccion(clave, ids, titulo, punto)
        _MONITORES.append(monitor)
        monitor.start()


def _post_trakt(ruta, cuerpo, client_id):
    """POST JSON a Trakt con las cabeceras exigidas por el device flow."""
    url = '%s/%s' % (TRAKT_API_BASE, str(ruta).lstrip('/'))
    cabeceras = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': client_id,
        'User-Agent': TRAKT_USER_AGENT,
    }
    datos = json.dumps(cuerpo).encode('utf-8')
    peticion = urllib.request.Request(url, data=datos, headers=cabeceras, method='POST')
    try:
        with urllib.request.urlopen(peticion, timeout=20) as respuesta:
            texto = respuesta.read().decode('utf-8', errors='ignore')
    except urllib.error.HTTPError as exc:
        try:
            cuerpo_error = exc.read().decode('utf-8', errors='ignore')
        except (OSError, ValueError, AttributeError):
            cuerpo_error = ''
        raise trakt.TraktError('HTTP %d en %s: %s' % (
            exc.code, ruta, cuerpo_error.strip() or str(exc)), exc.code, cuerpo_error)
    except (urllib.error.URLError, OSError, TypeError, ValueError, UnicodeError) as exc:
        raise trakt.TraktError('No se pudo conectar con Trakt (%s): %s' % (ruta, exc))
    try:
        return json.loads(texto) if texto.strip() else {}
    except ValueError as exc:
        raise trakt.TraktError('Respuesta no válida de Trakt (%s): %s' % (ruta, exc))


def autorizar_trakt():
    """Ejecuta el device flow de Trakt desde plugin o desde RunScript."""
    global _TRAKT_VISTAS, _TRAKT_PROGRESOS, _TRAKT_PROGRESOS_PRECARGA
    cliente = crear_cliente_trakt()
    cliente_id = str(ADDON.getSetting("trakt_client_id").strip())
    progreso = xbmcgui.DialogProgress()
    creado = False
    try:
        try:
            xbmc.executebuiltin('Dialog.Close(all,true)')
        except Exception:
            pass
        if not cliente_id:
            raise Exception(
                'Falta trakt_client_id. Introduce el Client ID de Trakt en los '
                'ajustes de Gaia y vuelve a pulsar "Autorizar cuenta de Trakt".')

        codigo = _post_trakt('/oauth/device/code', {'client_id': cliente_id}, cliente_id)
        dispositivo = str(codigo.get('device_code') or '').strip()
        usuario = str(codigo.get('user_code') or '').strip()
        if not dispositivo or not usuario:
            raise Exception('Trakt no devolvió device_code/user_code: %s' % codigo)

        url = str(codigo.get('verification_url') or
                  TRAKT_URL_ACTIVACION).strip() or TRAKT_URL_ACTIVACION
        intervalo = max(1, _entero(codigo.get('interval'), 5))
        duracion = max(intervalo, _entero(codigo.get('expires_in'), 600))
        fin = time.time() + duracion
        proximo = 0.0
        mensaje = ('1. Entra en: %s\n2. Introduce el código: %s\n'
                   '3. Esperando autorización...') % (url, usuario)
        try:
            xbmc.executebuiltin('Dialog.Close(all,true)')
        except Exception:
            pass
        progreso.create('Autorizar Trakt', mensaje)
        creado = True

        while time.time() < fin:
            if progreso.iscanceled():
                raise trakt.TraktError(
                    'Autorización de Trakt cancelada.', esperada=True)
            restante = max(0, int(fin - time.time()))
            porcentaje = min(99, int(100 * (1 - restante / float(duracion))))
            if creado:
                progreso.update(porcentaje, '%s (%ds)' % (mensaje, restante))

            if time.time() >= proximo:
                try:
                    token = _post_trakt(
                        '/oauth/device/token',
                        {'code': dispositivo, 'client_id': cliente_id},
                        cliente_id)
                    if str(token.get('access_token') or '').strip():
                        if not cliente.guardar_token(token):
                            raise trakt.TraktError(
                                'No se pudo guardar la sesión de Trakt en el perfil.')
                        _TRAKT_VISTAS = None
                        _TRAKT_PROGRESOS = None
                        _TRAKT_PROGRESOS_PRECARGA = False
                        if creado:
                            progreso.update(100, 'Cuenta vinculada.')
                        xbmcgui.Dialog().notification(
                            'Gaia - Trakt',
                            mensaje_trakt(32019, 'Cuenta de Trakt vinculada.'),
                            xbmcgui.NOTIFICATION_INFO, 5000)
                        return True
                except trakt.TraktError as exc:
                    tipo = trakt.clasificar_error_autorizacion(exc.estado, exc.cuerpo)
                    if tipo == 'expirado':
                        raise trakt.TraktError(
                            'El código de Trakt ha caducado. Pulsa "Autorizar cuenta de '
                            'Trakt" para generar uno nuevo.', esperada=True)
                    if tipo == 'rechazado':
                        raise trakt.TraktError(
                            'La autorización de Trakt fue rechazada. Vuelve a intentarlo '
                            'y aprueba el código en %s.' % url, esperada=True)
                    if tipo == 'lento':
                        intervalo += 5
                    elif tipo != 'pendiente':
                        raise
                proximo = time.time() + intervalo

            xbmc.sleep(1000)

        raise trakt.TraktError(
            'Se agotó el tiempo para autorizar Trakt. Vuelve a pulsar "Autorizar '
            'cuenta de Trakt".', esperada=True)
    except Exception as exc:
        esperada = getattr(exc, 'esperada', False)
        try:
            progreso.close()
        except Exception:
            pass
        xbmc.log('[Gaia] Trakt: %s' % exc,
                 xbmc.LOGDEBUG if esperada else xbmc.LOGWARNING)
        xbmcgui.Dialog().ok(
            'Autorizar Trakt' if esperada else 'Error Trakt', str(exc))
        return False
    finally:
        try:
            progreso.close()
        except Exception:
            pass



def revocar_trakt():
    """Elimina los tokens guardados y avisa del resultado."""
    global _TRAKT_VISTAS, _TRAKT_PROGRESOS, _TRAKT_PROGRESOS_PRECARGA
    try:
        crear_cliente_trakt().revocar()
        _TRAKT_VISTAS = None
        _TRAKT_PROGRESOS = None
        _TRAKT_PROGRESOS_PRECARGA = False
        xbmcgui.Dialog().notification(
            'Gaia - Trakt', mensaje_trakt(32020, 'Cuenta de Trakt desvinculada.'),
            xbmcgui.NOTIFICATION_INFO, 5000)
    except Exception as exc:
        xbmc.log('[Gaia] Error desvinculando Trakt: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().ok('Error Trakt', str(exc))


def autorizar_alldebrid():
    """Vincula AllDebrid por PIN desde plugin o desde RunScript."""
    try:
        alldebrid.vincular_pin(ADDON.setSetting)
    except alldebrid.AllDebridPinError as exc:
        esperada = getattr(exc, 'esperada', False)
        xbmc.log('[Gaia] AllDebrid PIN: %s' % exc,
                 xbmc.LOGDEBUG if esperada else xbmc.LOGWARNING)
        xbmcgui.Dialog().ok(
            'Vincular AllDebrid' if esperada else 'Error AllDebrid', str(exc))
    except Exception as exc:
        xbmc.log('[Gaia] Error inesperado vinculando AllDebrid: %s' % exc,
                 xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Error AllDebrid', str(exc))


def revocar_alldebrid():
    """Borra la API Key guardada y notifica la desvinculación."""
    try:
        ADDON.setSetting('alldebrid_apikey', '')
        try:
            xbmcvfs.delete(os.path.join(ruta_perfil(), 'alldebrid_cache.json'))
        except Exception:
            pass
        xbmcgui.Dialog().notification(
            'Gaia - AllDebrid', 'Cuenta de AllDebrid desvinculada.',
            xbmcgui.NOTIFICATION_INFO, 5000)
    except Exception as exc:
        xbmc.log('[Gaia] Error desvinculando AllDebrid: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().ok('Error AllDebrid', str(exc))


def enrutar():
    if ACCION_SCRIPT == 'refresh_catalog':
        refresh_catalog()
        return
    if ACCION_SCRIPT == 'trakt_auth':
        autorizar_trakt()
        return
    if ACCION_SCRIPT == 'trakt_revoke':
        revocar_trakt()
        return
    if ACCION_SCRIPT == 'alldebrid_pin':
        autorizar_alldebrid()
        return
    if     ACCION_SCRIPT == 'refresh_catalog':
        refresh_catalog()
        return
    if ACCION_SCRIPT == 'alldebrid_revoke':
        revocar_alldebrid()
        return

    accion = ARGUMENTOS.get('action', 'main')
    if accion == 'ajustes':
        abrir_ajustes()
    elif accion == 'trakt_auth':
        autorizar_trakt()
    elif accion == 'trakt_revoke':
        revocar_trakt()
    elif accion == 'alldebrid_pin':
        autorizar_alldebrid()
    elif accion == 'alldebrid_revoke':
        revocar_alldebrid()
    elif accion == 'refresh_catalog':
        refresh_catalog()
    elif accion == 'categoria':
        listar_categoria(ARGUMENTOS.get('categoria', ''))
    elif accion == 'serie':
        listar_temporadas(ARGUMENTOS.get('categoria', ''), ARGUMENTOS.get('serie', ''))
    elif accion == 'temporada':
        listar_episodios(ARGUMENTOS.get('categoria', ''), ARGUMENTOS.get('serie', ''),
                         ARGUMENTOS.get('temporada', '1'))
    elif accion == 'play':
        reproducir(ARGUMENTOS.get('enlace', ''), ARGUMENTOS.get('titulo', ''),
                   ARGUMENTOS.get('fuentes', ''), ARGUMENTOS.get('trakt', ''),
                   ARGUMENTOS.get('resume', ''))
    else:
        menu_principal()


try:
    enrutar()
except Exception as exc:  # Evita dejar al usuario sin feedback ante un fallo inesperado.
    xbmc.log('[Gaia] Error inesperado: %s' % exc, xbmc.LOGERROR)
    if ACCION_SCRIPT:
        titulo = ('Error Trakt' if ACCION_SCRIPT in ('trakt_auth', 'trakt_revoke')
                  else 'Gaia')
        xbmcgui.Dialog().ok(titulo, str(exc))
    else:
        xbmcgui.Dialog().notification('Gaia', 'Se produjo un error inesperado.',
                                      xbmcgui.NOTIFICATION_ERROR, 5000)
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
