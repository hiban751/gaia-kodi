# -*- coding: utf-8 -*-
"""Cliente de Trakt para Gaia compatible con Kodi 20/21 (Python 3).

Implementa el flujo de dispositivo (device code), guarda los tokens en el
perfil del addon y sincroniza el historial y el progreso de películas.
Solamente usa la biblioteca estándar, por lo que funciona en PC, Fire TV y Android.
"""

import json
import os
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib import parser

API_BASE = 'https://api.trakt.tv'
URL_ACTIVACION = 'https://auth.trakt.tv/activate'
AGENTE = 'GaiaKodi/1.0'
TIEMPO_ESPERA = 20
TIEMPO_ESPERA_PROGRESO = 5
ARCHIVO_TOKENS = 'trakt_tokens.json'
ARCHIVO_VISTAS = 'trakt_watched.json'
ARCHIVO_PROGRESO = 'trakt_playback.json'
CADUCIDAD_VISTAS = 15 * 60
CADUCIDAD_PROGRESO = 15 * 60
ESTADOS_PENDIENTES = (400, 409, 429)
ESTADOS_FATALES = (401, 403, 404, 410, 418)
ERRORES_PENDIENTES = ('authorization_pending', 'slow_down', 'pending')
ERRORES_FATALES = ('expired_token', 'access_denied')


class TraktError(Exception):
    """Error de configuración, red o respuesta de la API de Trakt."""

    def __init__(self, mensaje, estado=None, cuerpo='', esperada=False):
        Exception.__init__(self, mensaje)
        self.estado = estado
        self.cuerpo = cuerpo
        self.esperada = esperada


def _entero(valor, defecto=0):
    try:
        return int(valor)
    except (TypeError, ValueError):
        return defecto


def _flotante(valor, defecto=0.0):
    try:
        return float(valor)
    except (TypeError, ValueError):
        return defecto


def _detalle_error(cuerpo):
    """Extrae el código/error descriptivo de una respuesta OAuth fallida."""
    try:
        datos = json.loads(cuerpo or '{}')
    except (TypeError, ValueError):
        return ''
    if not isinstance(datos, dict):
        return ''
    return str(datos.get('error') or datos.get('error_description') or '').strip()


def clasificar_error_autorizacion(estado, cuerpo):
    """Clasifica un error de device/token para decidir si se sigue esperando."""
    texto = str(cuerpo or '').strip()
    error = _detalle_error(texto).lower().replace(' ', '_').replace('-', '_')
    if error in ERRORES_FATALES:
        return 'expirado' if error == 'expired_token' else 'rechazado'
    if error == 'slow_down' or estado == 429:
        return 'lento'
    if error in ERRORES_PENDIENTES:
        return 'pendiente'
    if not texto and estado in ESTADOS_PENDIENTES:
        return 'pendiente'
    return 'error'


def _ruta_archivo(perfil, nombre):
    """Resuelve una ruta del perfil del addon y se asegura de que exista."""
    if not perfil:
        return ''
    try:
        carpeta = (xbmcvfs.translatePath(perfil) if hasattr(xbmcvfs, 'translatePath')
                   else xbmc.translatePath(perfil))
    except (AttributeError, TypeError, OSError, ValueError):
        return ''
    if not carpeta:
        return ''
    try:
        xbmcvfs.mkdirs(carpeta)
    except (OSError, TypeError):
        pass
    return os.path.join(carpeta, nombre)


def _leer_json(ruta):
    """Lee un JSON del perfil; cualquier problema se trata como archivo vacío."""
    if not ruta:
        return {}
    try:
        with open(ruta, 'r', encoding='utf-8') as archivo:
            datos = json.load(archivo)
        return datos if isinstance(datos, dict) else {}
    except (OSError, ValueError, TypeError, UnicodeError):
        return {}


def _escribir_json(ruta, datos):
    """Escribe un JSON de forma atómica dentro del perfil del addon."""
    if not ruta:
        return False
    try:
        temporal = '%s.tmp' % ruta
        with open(temporal, 'w', encoding='utf-8') as archivo:
            json.dump(datos, archivo, ensure_ascii=False)
        os.replace(temporal, ruta)
        return True
    except (OSError, TypeError, ValueError, UnicodeError) as exc:
        xbmc.log('[Gaia] Trakt no pudo guardar %s: %s' % (os.path.basename(ruta), exc),
                 xbmc.LOGWARNING)
        return False


def _hora_utc():
    """Devuelve una fecha UTC válida para Trakt."""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')


def claves_pelicula(titulo=None, anio=None, tmdb=None, imdb=None):
    """Genera las claves con las que Gaia compara una película con Trakt."""
    claves = set()
    if tmdb not in (None, ''):
        valor = str(tmdb).strip()
        if valor:
            claves.add('tmdb:%s' % valor)
    if imdb:
        valor = str(imdb).strip().lower()
        if valor:
            claves.add('imdb:%s' % valor)

    normalizado = parser.normalizar_texto(titulo)
    if normalizado:
        claves.add(normalizado)
        anio = _entero(anio) or None
        if anio:
            claves.add('%s:%d' % (normalizado, anio))
    return claves


def _claves_de_vista(entrada):
    """Convierte un elemento de /watched/movies en claves comparables."""
    if not isinstance(entrada, dict):
        return set()
    pelicula = entrada.get('movie') if isinstance(entrada.get('movie'), dict) else entrada
    ids = pelicula.get('ids') if isinstance(pelicula.get('ids'), dict) else {}
    return claves_pelicula(titulo=pelicula.get('title'), anio=pelicula.get('year'),
                           tmdb=ids.get('tmdb'), imdb=ids.get('imdb'))


class TraktClient(object):
    """Acceso a Trakt: autorización, tokens e historial de películas."""

    def __init__(self, client_id='', profile=None):
        """Solo necesita el Client ID; Trakt no entrega secret en este flujo."""
        self.client_id = str(client_id or '').strip()
        self.ruta_tokens = _ruta_archivo(profile, ARCHIVO_TOKENS)
        self.ruta_vistas = _ruta_archivo(profile, ARCHIVO_VISTAS)
        self.ruta_progreso = _ruta_archivo(profile, ARCHIVO_PROGRESO)

    def _validar_cliente(self):
        if not self.client_id:
            raise TraktError(
                'Falta el Client ID de Trakt. Configura "Trakt Client ID" en los '
                'ajustes de Gaia y vuelve a intentarlo.')
        return True

    # ------------------------------------------------------------- tokens

    def _leer_tokens(self):
        return _leer_json(self.ruta_tokens)

    def _caducado(self, tokens=None):
        tokens = tokens if tokens is not None else self._leer_tokens()
        expira = _entero(tokens.get('expires_at'))
        return bool(expira and time.time() >= expira - 60)

    def guardar_token(self, respuesta, codigo_verificador=''):
        """Persiste access/refresh token y su caducidad absoluta."""
        access_token = str((respuesta or {}).get('access_token') or '').strip()
        if not access_token:
            return False

        creado = _entero((respuesta or {}).get('created_at')) or int(time.time())
        segundos = _entero((respuesta or {}).get('expires_in'), 7 * 24 * 3600)
        datos = {
            'access_token': access_token,
            'refresh_token': str((respuesta or {}).get('refresh_token') or ''),
            'created_at': creado,
            'expires_in': segundos,
            'expires_at': creado + segundos,
            'client_id': self.client_id,
            'code_verifier': codigo_verificador,
            'actualizado_en': time.time(),
        }
        return _escribir_json(self.ruta_tokens, datos)

    def esta_autorizado(self):
        """Indica si hay una sesión de Trakt utilizada por Gaia."""
        tokens = self._leer_tokens()
        if not tokens.get('access_token'):
            return False
        if tokens.get('client_id') and tokens.get('client_id') != self.client_id:
            return False
        return bool(tokens.get('refresh_token') or not self._caducado(tokens))

    def refrescar_token(self):
        """Renueva la sesión; los refresh tokens de Trakt son de un solo uso."""
        tokens = self._leer_tokens()
        refresh_token = str(tokens.get('refresh_token') or '').strip()
        if not refresh_token:
            return False

        cuerpo = {
            'refresh_token': refresh_token,
            'client_id': self.client_id,
            'redirect_uri': 'urn:ietf:wg:oauth:2.0:oob',
            'grant_type': 'refresh_token',
        }
        if tokens.get('code_verifier'):
            cuerpo['code_verifier'] = tokens['code_verifier']

        try:
            respuesta = self._peticion('/oauth/token', metodo='POST', cuerpo=cuerpo,
                                       autorizado=False, reintentar=False)
        except TraktError as exc:
            xbmc.log('[Gaia] Trakt no pudo refrescar la sesión: %s' % exc, xbmc.LOGDEBUG)
            return False
        if not respuesta.get('access_token'):
            return False
        return self.guardar_token(respuesta, str(tokens.get('code_verifier') or ''))

    # ----------------------------------------------------------------- red

    def _peticion(self, ruta, metodo='GET', cuerpo=None, autorizado=True,
                  reintentar=True, timeout=None):
        """Llama a la API de Trakt y devuelve el JSON, o lanza TraktError."""
        access_token = ''
        if autorizado:
            tokens = self._leer_tokens()
            if not tokens.get('access_token'):
                raise TraktError('Trakt no está autorizado.')
            if self._caducado(tokens) and not self.refrescar_token():
                raise TraktError('La sesión de Trakt ha caducado. Autoriza de nuevo la cuenta.')
            access_token = str(self._leer_tokens().get('access_token') or '')

        url = '%s/%s' % (API_BASE, str(ruta).lstrip('/'))
        cabeceras = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'User-Agent': AGENTE,
            'trakt-api-version': '2',
            'trakt-api-key': self.client_id,
        }
        if autorizado and access_token:
            cabeceras['Authorization'] = 'Bearer %s' % access_token

        contenido = json.dumps(cuerpo).encode('utf-8') if cuerpo is not None else None
        peticion = urllib.request.Request(url, data=contenido, headers=cabeceras,
                                          method=metodo)
        try:
            with urllib.request.urlopen(peticion, timeout=timeout or TIEMPO_ESPERA) as respuesta:
                texto = respuesta.read().decode('utf-8')
            return json.loads(texto) if texto else {}
        except urllib.error.HTTPError as exc:
            try:
                cuerpo_error = exc.read().decode('utf-8', errors='ignore')
            except (OSError, ValueError, AttributeError):
                cuerpo_error = ''
            if exc.code == 401 and autorizado and reintentar and self.refrescar_token():
                return self._peticion(ruta, metodo=metodo, cuerpo=cuerpo,
                                      autorizado=autorizado, reintentar=False,
                                      timeout=timeout)
            detalle = _detalle_error(cuerpo_error)
            raise TraktError(detalle or ('Trakt devolvió el error HTTP %d.' % exc.code),
                             exc.code, cuerpo_error)
        except (urllib.error.URLError, OSError, TypeError, ValueError, UnicodeError) as exc:
            raise TraktError('No se pudo conectar con Trakt: %s' % exc)

    # -------------------------------------------------------- autorización

    def autorizar(self):
        """Ejecuta el device flow de Trakt y guarda los tokens resultantes."""
        self._validar_cliente()
        cuerpo_codigo = {'client_id': self.client_id}

        try:
            codigo = self._peticion('/oauth/device/code', metodo='POST',
                                    cuerpo=cuerpo_codigo, autorizado=False)
        except TraktError as exc:
            raise TraktError('No se pudo iniciar la autorización de Trakt. %s' % exc)

        dispositivo = str(codigo.get('device_code') or '').strip()
        usuario = str(codigo.get('user_code') or '').strip()
        if not dispositivo or not usuario:
            raise TraktError('Trakt no devolvió un código de dispositivo válido.')

        url = str(codigo.get('verification_url') or URL_ACTIVACION).strip() or URL_ACTIVACION
        intervalo = max(1, _entero(codigo.get('interval'), 5))
        duracion = max(intervalo, _entero(codigo.get('expires_in'), 600))
        fin = time.time() + duracion

        cuerpo_token = {
            'code': dispositivo,
            'client_id': self.client_id,
        }

        mensaje = ('1. Entra en: %s\n2. Introduce el código: %s\n'
                   '3. Esperando autorización...') % (url, usuario)
        dialogo = xbmcgui.DialogProgress()
        creado = False
        try:
            dialogo.create('Gaia - Trakt', mensaje)
            creado = True
            siguiente = 0
            while time.time() < fin:
                if dialogo.iscanceled():
                    raise TraktError('Autorización de Trakt cancelada.', esperada=True)

                restante = max(0, int(fin - time.time()))
                porcentaje = min(99, int(100 * (1 - restante / float(duracion))))
                if creado:
                    dialogo.update(porcentaje, '%s (%ds)' % (mensaje, restante))

                if time.time() >= siguiente:
                    try:
                        token = self._peticion('/oauth/device/token', metodo='POST',
                                               cuerpo=cuerpo_token, autorizado=False)
                        if token.get('access_token'):
                            if not self.guardar_token(token):
                                raise TraktError(
                                    'No se pudo guardar la sesión de Trakt en el perfil.')
                            if creado:
                                dialogo.update(100, 'Cuenta vinculada.')
                            return True
                    except TraktError as exc:
                        tipo = clasificar_error_autorizacion(exc.estado, exc.cuerpo)
                        if tipo == 'expirado':
                            raise TraktError(
                                'El código de Trakt ha caducado. Pulsa "Autorizar cuenta '
                                'de Trakt" para generar uno nuevo.', esperada=True)
                        if tipo == 'rechazado':
                            raise TraktError(
                                'La autorización de Trakt fue rechazada. Vuelve a intentarlo '
                                'y aprueba el código en %s.' % url, esperada=True)
                        if tipo == 'lento':
                            intervalo += 5
                        elif tipo != 'pendiente':
                            raise TraktError('No se pudo autorizar Trakt. %s' % exc)
                    siguiente = time.time() + intervalo

                xbmc.sleep(1000)

            raise TraktError(
                'Se agotó el tiempo para autorizar Trakt. Vuelve a pulsar "Autorizar '
                'cuenta de Trakt".', esperada=True)
        finally:
            try:
                dialogo.close()
            except Exception:
                pass

    def revocar(self):
        """Borra la sesión local y avisa a Trakt cuando es posible."""
        tokens = self._leer_tokens()
        access_token = str(tokens.get('access_token') or '').strip()
        if access_token:
            try:
                self._peticion('/oauth/revoke', metodo='POST',
                               cuerpo={'token': access_token}, autorizado=False)
            except TraktError as exc:
                xbmc.log('[Gaia] Trakt no pudo revocar en remoto: %s' % exc, xbmc.LOGDEBUG)
        for ruta in (self.ruta_tokens, self.ruta_vistas, self.ruta_progreso):
            if not ruta:
                continue
            try:
                os.remove(ruta)
            except OSError:
                pass
        return True

    # ------------------------------------------------------------ historial

    def peliculas_vistas(self):
        """Consulta GET /users/me/watched/movies y devuelve la lista de Trakt."""
        datos = self._peticion('/users/me/watched/movies')
        return datos if isinstance(datos, list) else []

    def claves_peliculas_vistas(self, usar_cache=True):
        """Devuelve las claves de las películas ya vistas en Trakt."""
        if usar_cache and self.ruta_vistas:
            guardado = _leer_json(self.ruta_vistas)
            actualizado = _entero(guardado.get('actualizado_en', 0), 0)
            if time.time() - actualizado < CADUCIDAD_VISTAS:
                return set(str(clave) for clave in guardado.get('claves') or [])

        claves = set()
        for entrada in self.peliculas_vistas():
            claves |= _claves_de_vista(entrada)

        if self.ruta_vistas:
            _escribir_json(self.ruta_vistas, {
                'actualizado_en': time.time(),
                'claves': sorted(claves),
            })
        return claves

    @staticmethod
    def _objeto_pelicula(titulo=None, anio=None, tmdb=None, imdb=None):
        """Construye el objeto movie que aceptan todos los endpoints de Trakt."""
        ids = {}
        if tmdb not in (None, ''):
            ids['tmdb'] = _entero(tmdb) or str(tmdb).strip()
        if imdb:
            ids['imdb'] = str(imdb).strip()

        pelicula = {}
        if ids:
            pelicula['ids'] = ids
        else:
            titulo = str(titulo or '').strip()
            if titulo:
                pelicula['title'] = titulo
            anio = _entero(anio) or None
            if anio:
                pelicula['year'] = anio

        if not pelicula:
            raise TraktError('No hay datos suficientes para identificar la película en Trakt.')
        return pelicula

    def marcar_pelicula(self, titulo=None, anio=None, tmdb=None, imdb=None):
        """Añade una película al historial de Trakt (/sync/history)."""
        pelicula = self._objeto_pelicula(titulo=titulo, anio=anio, tmdb=tmdb, imdb=imdb)
        pelicula['watched_at'] = _hora_utc()
        return self._peticion('/sync/history', metodo='POST',
                              cuerpo={'movies': [pelicula]})

    def scrobble(self, accion, titulo=None, anio=None, tmdb=None, imdb=None, progreso=None):
        """Envía start/pause/stop con el porcentaje visto de la película."""
        if accion not in ('start', 'pause', 'stop'):
            raise TraktError('Acción de scrobble no válida: %s' % accion)
        pelicula = self._objeto_pelicula(titulo=titulo, anio=anio, tmdb=tmdb, imdb=imdb)
        if progreso is not None:
            pelicula['progress'] = round(min(100.0, max(0.0, _flotante(progreso))), 1)
        return self._peticion('/scrobble/%s' % accion, metodo='POST',
                              cuerpo={'movie': pelicula}, timeout=TIEMPO_ESPERA_PROGRESO)

    def progresos_peliculas(self, usar_cache=True, timeout=None):
        """Consulta GET /sync/playback/movies y devuelve progresos por clave."""
        if usar_cache and self.ruta_progreso:
            guardado = _leer_json(self.ruta_progreso)
            actualizado = _entero(guardado.get('actualizado_en', 0), 0)
            if time.time() - actualizado < CADUCIDAD_PROGRESO:
                datos = guardado.get('progresos') or {}
                return datos if isinstance(datos, dict) else {}

        respuesta = self._peticion('/sync/playback/movies',
                                   timeout=timeout or TIEMPO_ESPERA_PROGRESO)
        if not isinstance(respuesta, list):
            respuesta = []

        progresos = {}
        for entrada in respuesta:
            candidato = {
                'progreso': round(min(100.0, max(0.0, _flotante(
                    entrada.get('progress')))), 1),
                'paused_at': str(entrada.get('paused_at') or ''),
            }
            for clave in _claves_de_vista(entrada):
                actual = progresos.get(clave)
                if actual is None or candidato['progreso'] > _flotante(
                        actual.get('progreso')):
                    progresos[clave] = candidato

        if self.ruta_progreso:
            _escribir_json(self.ruta_progreso, {
                'actualizado_en': time.time(),
                'progresos': progresos,
            })
        return progresos

    def progreso_de_pelicula(self, ids, progresos=None, usar_cache=True, timeout=None):
        """Devuelve el progreso de Trakt para una película identificada por ids."""
        ids = ids or {}
        if progresos is None:
            try:
                progresos = self.progresos_peliculas(usar_cache=usar_cache, timeout=timeout)
            except TraktError:
                return {}

        claves = claves_pelicula(titulo=ids.get('titulo'), anio=ids.get('anio'),
                                 tmdb=ids.get('tmdb'), imdb=ids.get('imdb'))
        mejor = None
        for clave in claves:
            candidato = (progresos or {}).get(clave)
            if not isinstance(candidato, dict):
                continue
            if _flotante(candidato.get('progreso')) <= 0:
                continue
            if mejor is None or _flotante(candidato.get('progreso')) > _flotante(
                    mejor.get('progreso')):
                mejor = candidato
        return mejor or {}
